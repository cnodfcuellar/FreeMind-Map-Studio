import React, { useState, useRef, useEffect } from 'react';
import { MindNode, NodeShape } from '../types/mindmap';
import {
  Plus,
  FolderPlus,
  Trash2,
  Minimize2,
  Maximize2,
  Bold,
  Italic,
  Undo2,
  Redo2,
  Sliders,
  ListTree,
  Presentation,
  Search,
  Link,
  Cloud,
  FileDown,
  MoreHorizontal,
  ChevronDown,
} from 'lucide-react';

interface ToolBarProps {
  selectedNode: MindNode | null;
  canUndo: boolean;
  canRedo: boolean;
  isOutlineMode: boolean;
  isFilterBarOpen: boolean;
  isToolPanelOpen: boolean;
  onAddChild: () => void;
  onAddSibling: () => void;
  onDeleteNode: () => void;
  onToggleFold: () => void;
  onToggleBold: () => void;
  onToggleItalic: () => void;
  onChangeShape: (shape: NodeShape) => void;
  onUndo: () => void;
  onRedo: () => void;
  onToggleOutline: () => void;
  onStartPresentation: () => void;
  onToggleFilterBar: () => void;
  onToggleToolPanel: () => void;
  onOpenConnectorModal: () => void;
  onToggleCloud: () => void;
  onOpenExportModal: () => void;
  onOpenIconPackModal?: () => void;
}

export const ToolBar: React.FC<ToolBarProps> = ({
  selectedNode,
  canUndo,
  canRedo,
  isOutlineMode,
  isFilterBarOpen,
  isToolPanelOpen,
  onAddChild,
  onAddSibling,
  onDeleteNode,
  onToggleFold,
  onToggleBold,
  onToggleItalic,
  onChangeShape,
  onUndo,
  onRedo,
  onToggleOutline,
  onStartPresentation,
  onToggleFilterBar,
  onToggleToolPanel,
  onOpenConnectorModal,
  onToggleCloud,
  onOpenExportModal,
  onOpenIconPackModal,
}) => {
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);
  const moreMenuRef = useRef<HTMLDivElement>(null);

  // Close more menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (moreMenuRef.current && !moreMenuRef.current.contains(e.target as Node)) {
        setIsMoreMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="h-11 bg-white border-b border-slate-200 px-2 sm:px-3 flex items-center justify-between gap-1 sm:gap-2 z-20 shrink-0 select-none overflow-x-auto overflow-y-hidden scrollbar-none">
      {/* Left group: Node Actions & History */}
      <div className="flex items-center gap-0.5 sm:gap-1 shrink-0">
        {/* Undo / Redo */}
        <div className="flex items-center">
          <button
            title="Deshacer (Ctrl+Z)"
            disabled={!canUndo}
            onClick={onUndo}
            className="p-1.5 rounded-lg text-slate-700 hover:bg-slate-100 disabled:opacity-35 disabled:hover:bg-transparent transition-colors min-w-[30px] min-h-[30px] flex items-center justify-center"
          >
            <Undo2 className="w-4 h-4" />
          </button>
          <button
            title="Rehacer (Ctrl+Y)"
            disabled={!canRedo}
            onClick={onRedo}
            className="p-1.5 rounded-lg text-slate-700 hover:bg-slate-100 disabled:opacity-35 disabled:hover:bg-transparent transition-colors min-w-[30px] min-h-[30px] flex items-center justify-center"
          >
            <Redo2 className="w-4 h-4" />
          </button>
        </div>

        <div className="w-px h-5 bg-slate-200 mx-0.5 sm:mx-1 shrink-0" />

        {/* Add Child */}
        <button
          title="Agregar Nodo Hijo (Tab o Insert)"
          onClick={onAddChild}
          className="flex items-center gap-1 px-2 sm:px-2.5 py-1.5 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 font-semibold text-xs transition-colors shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Hijo</span>
        </button>

        {/* Add Sibling */}
        <button
          title="Agregar Nodo Hermano (Enter)"
          onClick={onAddSibling}
          className="flex items-center gap-1 px-2 sm:px-2.5 py-1.5 rounded-lg text-slate-700 hover:bg-slate-100 font-semibold text-xs transition-colors shrink-0"
        >
          <FolderPlus className="w-3.5 h-3.5 text-emerald-600" />
          <span className="hidden sm:inline">Hermano</span>
        </button>

        {/* Delete */}
        <button
          title="Eliminar Nodo Seleccionado (Supr / Delete)"
          disabled={!selectedNode || selectedNode.parentId === null}
          onClick={onDeleteNode}
          className="p-1.5 rounded-lg text-slate-700 hover:bg-red-50 hover:text-red-600 disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-slate-700 transition-colors min-w-[30px] min-h-[30px] flex items-center justify-center shrink-0"
        >
          <Trash2 className="w-4 h-4" />
        </button>

        {/* Fold / Unfold */}
        <button
          title="Plegar / Desplegar Rama (Espacio)"
          disabled={!selectedNode || !selectedNode.children || selectedNode.children.length === 0}
          onClick={onToggleFold}
          className="p-1.5 rounded-lg text-slate-700 hover:bg-slate-100 disabled:opacity-30 disabled:hover:bg-transparent transition-colors min-w-[30px] min-h-[30px] flex items-center justify-center shrink-0"
        >
          {selectedNode?.folded ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
        </button>

        <div className="w-px h-5 bg-slate-200 mx-0.5 sm:mx-1 shrink-0" />

        {/* Typography Quick Formats (visible from sm and up) */}
        <div className="hidden xs:flex items-center gap-0.5">
          <button
            title="Negrita (Bold)"
            disabled={!selectedNode}
            onClick={onToggleBold}
            className={`p-1.5 rounded-lg transition-colors min-w-[30px] min-h-[30px] flex items-center justify-center ${
              selectedNode?.bold ? 'bg-blue-100 text-blue-700 font-bold' : 'text-slate-700 hover:bg-slate-100'
            } disabled:opacity-30 disabled:hover:bg-transparent`}
          >
            <Bold className="w-3.5 h-3.5" />
          </button>

          <button
            title="Cursiva (Italic)"
            disabled={!selectedNode}
            onClick={onToggleItalic}
            className={`p-1.5 rounded-lg transition-colors min-w-[30px] min-h-[30px] flex items-center justify-center ${
              selectedNode?.italic ? 'bg-blue-100 text-blue-700' : 'text-slate-700 hover:bg-slate-100'
            } disabled:opacity-30 disabled:hover:bg-transparent`}
          >
            <Italic className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Shape Selector (Responsive compact width on smaller screens) */}
        <div className="hidden sm:block">
          <select
            disabled={!selectedNode}
            value={selectedNode?.shape || 'bubble'}
            onChange={(e) => onChangeShape(e.target.value as NodeShape)}
            className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 font-medium outline-none focus:border-blue-500 disabled:opacity-35 max-w-[105px] md:max-w-none truncate"
          >
            <option value="bubble">Burbuja</option>
            <option value="fork">Horquilla</option>
            <option value="rectangle">Rectángulo</option>
            <option value="oval">Óvalo</option>
            <option value="hexagon">Hexágono</option>
            <option value="pill">Cápsula</option>
          </select>
        </div>

        <div className="hidden md:block w-px h-5 bg-slate-200 mx-1 shrink-0" />

        {/* Connector (Desktop & Tablets) */}
        <button
          title="Crear Conector / Relación entre 2 nodos"
          disabled={!selectedNode}
          onClick={onOpenConnectorModal}
          className="hidden md:flex items-center gap-1 px-2 py-1.5 rounded-lg text-slate-700 hover:bg-slate-100 font-medium text-xs disabled:opacity-35 shrink-0"
        >
          <Link className="w-3.5 h-3.5 text-cyan-600" />
          <span className="hidden lg:inline">Conector</span>
        </button>

        {/* Cloud (Desktop & Tablets) */}
        <button
          title="Alternar Nube de Rama"
          disabled={!selectedNode}
          onClick={onToggleCloud}
          className={`hidden md:flex items-center gap-1 px-2 py-1.5 rounded-lg font-medium text-xs transition-colors ${
            selectedNode?.cloud?.enabled ? 'bg-amber-100 text-amber-800' : 'text-slate-700 hover:bg-slate-100'
          } disabled:opacity-35 shrink-0`}
        >
          <Cloud className="w-3.5 h-3.5 text-amber-500" />
          <span className="hidden lg:inline">Nube</span>
        </button>

        {/* 500+ Vector Icons Pack Trigger */}
        {onOpenIconPackModal && (
          <button
            title="Abrir pack de 500+ iconos vectoriales SVG para nodos"
            onClick={onOpenIconPackModal}
            className="flex items-center gap-1 px-2 py-1.5 rounded-lg text-slate-700 hover:bg-blue-50 hover:text-blue-600 font-medium text-xs transition-colors shrink-0"
          >
            <span className="w-3.5 h-3.5 flex items-center justify-center text-blue-600 font-bold text-xs">★</span>
            <span className="hidden lg:inline">Iconos SVG</span>
            <span className="hidden xl:inline px-1 py-0.2 bg-blue-100 text-blue-700 rounded-full text-[9px] font-bold">500+</span>
          </button>
        )}

        {/* Mobile "More Options" Menu Popover (for small screens) */}
        <div className="relative md:hidden shrink-0" ref={moreMenuRef}>
          <button
            title="Más opciones de nodo"
            onClick={() => setIsMoreMenuOpen((o) => !o)}
            className={`p-1.5 rounded-lg text-slate-700 hover:bg-slate-100 transition-colors min-w-[30px] min-h-[30px] flex items-center justify-center ${
              isMoreMenuOpen ? 'bg-slate-100 text-blue-600' : ''
            }`}
          >
            <MoreHorizontal className="w-4 h-4" />
          </button>

          {isMoreMenuOpen && (
            <div className="absolute top-full left-0 mt-1 w-52 bg-white text-slate-800 rounded-xl shadow-xl border border-slate-200 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100 text-xs">
              <div className="px-3 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Formato & Enlaces
              </div>

              {/* Mobile Shape selector */}
              <div className="px-3 py-1.5 flex items-center justify-between">
                <span className="text-slate-600">Forma:</span>
                <select
                  disabled={!selectedNode}
                  value={selectedNode?.shape || 'bubble'}
                  onChange={(e) => {
                    onChangeShape(e.target.value as NodeShape);
                    setIsMoreMenuOpen(false);
                  }}
                  className="bg-slate-50 border border-slate-200 rounded px-2 py-0.5 text-xs text-slate-700 outline-none"
                >
                  <option value="bubble">Burbuja</option>
                  <option value="fork">Horquilla</option>
                  <option value="rectangle">Rectángulo</option>
                  <option value="oval">Óvalo</option>
                  <option value="hexagon">Hexágono</option>
                  <option value="pill">Cápsula</option>
                </select>
              </div>

              <div className="my-1 border-t border-slate-100" />

              {/* Bold / Italic */}
              <div className="px-3 py-1 flex items-center justify-around gap-1">
                <button
                  disabled={!selectedNode}
                  onClick={() => {
                    onToggleBold();
                    setIsMoreMenuOpen(false);
                  }}
                  className={`flex-1 py-1 rounded text-center border ${
                    selectedNode?.bold ? 'bg-blue-50 border-blue-200 text-blue-700 font-bold' : 'border-slate-200 text-slate-700'
                  }`}
                >
                  Negrita
                </button>
                <button
                  disabled={!selectedNode}
                  onClick={() => {
                    onToggleItalic();
                    setIsMoreMenuOpen(false);
                  }}
                  className={`flex-1 py-1 rounded text-center border italic ${
                    selectedNode?.italic ? 'bg-blue-50 border-blue-200 text-blue-700' : 'border-slate-200 text-slate-700'
                  }`}
                >
                  Cursiva
                </button>
              </div>

              <div className="my-1 border-t border-slate-100" />

              <button
                disabled={!selectedNode}
                onClick={() => {
                  onOpenConnectorModal();
                  setIsMoreMenuOpen(false);
                }}
                className="w-full px-3 py-1.5 text-left flex items-center gap-2 hover:bg-slate-50 text-slate-700 disabled:opacity-40"
              >
                <Link className="w-3.5 h-3.5 text-cyan-600" />
                <span>Crear Conector flotante</span>
              </button>

              <button
                disabled={!selectedNode}
                onClick={() => {
                  onToggleCloud();
                  setIsMoreMenuOpen(false);
                }}
                className="w-full px-3 py-1.5 text-left flex items-center gap-2 hover:bg-slate-50 text-slate-700 disabled:opacity-40"
              >
                <Cloud className="w-3.5 h-3.5 text-amber-500" />
                <span>Alternar Nube de agrupación</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Right group: Modes & Panels */}
      <div className="flex items-center gap-0.5 sm:gap-1 shrink-0">
        {/* Search & Filter */}
        <button
          title="Buscar y Filtrar (Ctrl+F)"
          onClick={onToggleFilterBar}
          className={`p-1.5 rounded-lg transition-colors min-w-[30px] min-h-[30px] flex items-center justify-center shrink-0 ${
            isFilterBarOpen ? 'bg-blue-100 text-blue-700' : 'text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Search className="w-4 h-4" />
        </button>

        {/* Outline View Toggle */}
        <button
          title="Mostrar / Ocultar panel lateral de esquema (Alt+O)"
          onClick={onToggleOutline}
          className={`flex items-center gap-1 sm:gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-lg font-semibold text-xs transition-colors shrink-0 ${
            isOutlineMode ? 'bg-indigo-100 text-indigo-700 font-bold shadow-2xs' : 'text-slate-700 hover:bg-slate-100'
          }`}
        >
          <ListTree className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Esquema</span>
        </button>

        {/* Presentation Mode */}
        <button
          title="Iniciar Modo Presentación (F5)"
          onClick={onStartPresentation}
          className="flex items-center gap-1 sm:gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-lg text-slate-700 hover:bg-purple-50 hover:text-purple-700 font-semibold text-xs transition-colors shrink-0"
        >
          <Presentation className="w-3.5 h-3.5 text-purple-600" />
          <span className="hidden lg:inline">Presentar</span>
        </button>

        {/* Export / Portable HTML */}
        <button
          title="Exportar archivo .mm / HTML Portable / Imágenes"
          onClick={onOpenExportModal}
          className="flex items-center gap-1 sm:gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-blue-600 text-white hover:bg-blue-700 font-semibold text-xs shadow-xs transition-colors shrink-0"
        >
          <FileDown className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Exportar</span>
        </button>

        <div className="w-px h-5 bg-slate-200 mx-0.5 sm:mx-1 shrink-0" />

        {/* Toggle Tool Panel */}
        <button
          title="Alternar Panel de Propiedades (Alt+P)"
          onClick={onToggleToolPanel}
          className={`p-1.5 rounded-lg transition-colors min-w-[30px] min-h-[30px] flex items-center justify-center shrink-0 ${
            isToolPanelOpen ? 'bg-blue-100 text-blue-700' : 'text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Sliders className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

