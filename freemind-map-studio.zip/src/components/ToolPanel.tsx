import React, { useState, useMemo } from 'react';
import { MindNode, NodeShape, EdgeStyle, EdgeProfile, LayoutType, MindMapTheme, MindMap, Connector } from '../types/mindmap';
import { AVAILABLE_ICONS, renderNodeIcon } from '../utils/iconMap';
import {
  VECTOR_ICON_PACK,
  VECTOR_ICON_CATEGORIES,
  VectorIconCategory,
  searchVectorIcons,
  TOTAL_VECTOR_ICONS_COUNT,
} from '../utils/vectorIconPack';
import { THEMES } from '../utils/themes';
import {
  Palette,
  FileText,
  Smile,
  Cloud,
  Sliders,
  X,
  Bold,
  Italic,
  Type,
  ExternalLink,
  Plus,
  Trash2,
  Layers,
  ChevronRight,
  ChevronDown,
  AlignLeft,
  AlignCenter,
  AlignRight,
  GitFork,
  Link as LinkIcon,
  Share2,
  Check,
  RotateCcw,
  Sparkles,
  ArrowRight,
  MoveHorizontal,
  MoveVertical,
  Network,
  CircleDot,
  Compass,
  LayoutGrid,
  Search,
  Maximize2,
} from 'lucide-react';

interface ToolPanelProps {
  selectedNode: MindNode | null;
  currentTheme: MindMapTheme;
  layout: LayoutType;
  isOpen: boolean;
  onClose: () => void;
  onUpdateNode: (nodeId: string, updates: Partial<MindNode>) => void;
  onUpdateMapTheme: (themeId: string) => void;
  onUpdateMapLayout: (layout: LayoutType) => void;
  
  // Link & Connection types customization
  mindMap?: MindMap;
  onUpdateMapEdgeStyle?: (edgeStyle: EdgeStyle) => void;
  onUpdateMapEdgeProfile?: (edgeProfile: EdgeProfile) => void;
  onUpdateMapEdgeWidth?: (width: number) => void;
  onUpdateMapEdgeColor?: (color: string | undefined) => void;
  onUpdateMapEdgeDash?: (dash: 'solid' | 'dashed' | 'dotted') => void;
  onApplyEdgeStyleToAllNodes?: (edgeStyle: EdgeStyle) => void;
  onApplyEdgeProfileToAllNodes?: (edgeProfile: EdgeProfile) => void;
  onOpenConnectorModal?: (fromId?: string) => void;
  onDeleteConnector?: (connectorId: string) => void;
  onUpdateConnector?: (connectorId: string, updates: Partial<Connector>) => void;
  onUpdateMapGaps?: (gaps: { horizontal?: number; vertical?: number }) => void;
  onOpenIconPackModal?: () => void;
}

type TabType = 'content' | 'format' | 'notes' | 'icons' | 'clouds' | 'theme';

const COLOR_PRESETS = [
  '#ffffff', '#f8fafc', '#eff6ff', '#f0fdf4', '#fefce8', '#fff7ed', '#faf5ff', '#ecfeff',
  '#2563eb', '#059669', '#d97706', '#dc2626', '#7c3aed', '#0891b2', '#475569', '#0f172a'
];

const TEXT_COLOR_PRESETS = [
  '#0f172a', '#1e40af', '#166534', '#9a3412', '#6b21a8', '#991b1b', '#ffffff', '#475569'
];

export const ToolPanel: React.FC<ToolPanelProps> = ({
  selectedNode,
  currentTheme,
  layout,
  isOpen,
  onClose,
  onUpdateNode,
  onUpdateMapTheme,
  onUpdateMapLayout,
  mindMap,
  onUpdateMapEdgeStyle,
  onUpdateMapEdgeProfile,
  onUpdateMapEdgeWidth,
  onUpdateMapEdgeColor,
  onUpdateMapEdgeDash,
  onApplyEdgeStyleToAllNodes,
  onApplyEdgeProfileToAllNodes,
  onOpenConnectorModal,
  onDeleteConnector,
  onUpdateConnector,
  onUpdateMapGaps,
  onOpenIconPackModal,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('content');
  const [newTagInput, setNewTagInput] = useState('');
  const [showAppliedToast, setShowAppliedToast] = useState(false);
  const [iconSearchQuery, setIconSearchQuery] = useState('');
  const [iconCategory, setIconCategory] = useState<VectorIconCategory | 'all'>('all');
  const [mapSectionsOpen, setMapSectionsOpen] = useState<Record<string, boolean>>({
    edges: true,
    nodeEdge: true,
    connectors: true,
    gaps: true,
    layout: true,
    theme: true,
  });

  const filteredVectorIcons = useMemo(() => {
    return searchVectorIcons(iconSearchQuery, iconCategory);
  }, [iconSearchQuery, iconCategory]);

  const toggleMapSection = (section: string) => {
    setMapSectionsOpen(prev => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const handleExpandAllMapSections = (expand: boolean) => {
    setMapSectionsOpen({
      edges: expand,
      nodeEdge: expand,
      connectors: expand,
      gaps: expand,
      layout: expand,
      theme: expand,
    });
  };

  if (!isOpen) return null;

  const currentMapEdgeStyle: EdgeStyle = mindMap?.edgeStyle || currentTheme.edgeStyle || 'bezier';
  const currentMapEdgeProfile: EdgeProfile = mindMap?.edgeProfile || 'uniform';
  const currentMapEdgeWidth = mindMap?.edgeWidth || 2.5;
  const currentMapEdgeDash = mindMap?.edgeDash || 'solid';
  const currentMapEdgeColor = mindMap?.edgeColor;
  const currentHGap = mindMap?.horizontalGap !== undefined ? mindMap.horizontalGap : 54;
  const currentVGap = mindMap?.verticalGap !== undefined ? mindMap.verticalGap : 14;

  const handleApplyToAll = (style: EdgeStyle) => {
    if (onApplyEdgeStyleToAllNodes) {
      onApplyEdgeStyleToAllNodes(style);
      setShowAppliedToast(true);
      setTimeout(() => setShowAppliedToast(false), 2500);
    } else if (onUpdateMapEdgeStyle) {
      onUpdateMapEdgeStyle(style);
    }
  };

  const handleApplyProfileToAll = (profile: EdgeProfile) => {
    if (onApplyEdgeProfileToAllNodes) {
      onApplyEdgeProfileToAllNodes(profile);
      setShowAppliedToast(true);
      setTimeout(() => setShowAppliedToast(false), 2500);
    } else if (onUpdateMapEdgeProfile) {
      onUpdateMapEdgeProfile(profile);
    }
  };

  const handleShapeChange = (shape: NodeShape) => {
    if (!selectedNode) return;
    onUpdateNode(selectedNode.id, { shape });
  };

  const handleAddTag = () => {
    if (!selectedNode || !newTagInput.trim()) return;
    const currentTags = selectedNode.tags || [];
    if (!currentTags.includes(newTagInput.trim())) {
      onUpdateNode(selectedNode.id, { tags: [...currentTags, newTagInput.trim()] });
    }
    setNewTagInput('');
  };

  const handleRemoveTag = (tagToRemove: string) => {
    if (!selectedNode || !selectedNode.tags) return;
    onUpdateNode(selectedNode.id, {
      tags: selectedNode.tags.filter(t => t !== tagToRemove),
    });
  };

  const handleToggleIcon = (iconId: string) => {
    if (!selectedNode) return;
    const currentIcons = selectedNode.icons || [];
    if (currentIcons.includes(iconId)) {
      onUpdateNode(selectedNode.id, {
        icons: currentIcons.filter(id => id !== iconId),
      });
    } else {
      onUpdateNode(selectedNode.id, {
        icons: [...currentIcons, iconId],
      });
    }
  };

  return (
    <aside className="w-84 bg-white border-l border-slate-200 shadow-xl flex flex-col z-30 h-full overflow-hidden transition-all select-none">
      {/* Panel Header */}
      <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-blue-600" />
          <h2 className="font-semibold text-sm text-slate-800">Panel de Propiedades</h2>
        </div>
        <button
          onClick={onClose}
          className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Tabs Navigation */}
      <div className="flex border-b border-slate-200 bg-white px-1 overflow-x-auto text-xs font-medium">
        <button
          onClick={() => setActiveTab('content')}
          className={`flex items-center gap-1.5 px-3 py-2.5 border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'content'
              ? 'border-blue-600 text-blue-600 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Type className="w-3.5 h-3.5" /> Texto & Contenido
        </button>
        <button
          onClick={() => setActiveTab('format')}
          className={`flex items-center gap-1.5 px-3 py-2.5 border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'format'
              ? 'border-blue-600 text-blue-600 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Palette className="w-3.5 h-3.5" /> Estilos & Forma
        </button>
        <button
          onClick={() => setActiveTab('notes')}
          className={`flex items-center gap-1.5 px-3 py-2.5 border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'notes'
              ? 'border-blue-600 text-blue-600 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileText className="w-3.5 h-3.5" /> Notas
        </button>
        <button
          onClick={() => setActiveTab('icons')}
          className={`flex items-center gap-1.5 px-3 py-2.5 border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'icons'
              ? 'border-blue-600 text-blue-600 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Smile className="w-3.5 h-3.5" /> Iconos
        </button>
        <button
          onClick={() => setActiveTab('clouds')}
          className={`flex items-center gap-1.5 px-3 py-2.5 border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'clouds'
              ? 'border-blue-600 text-blue-600 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Cloud className="w-3.5 h-3.5" /> Nubes
        </button>
        <button
          onClick={() => setActiveTab('theme')}
          className={`flex items-center gap-1.5 px-3 py-2.5 border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'theme'
              ? 'border-blue-600 text-blue-600 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Layers className="w-3.5 h-3.5" /> Mapa
        </button>
      </div>

      {/* Tab Contents */}
      <div className="flex-1 overflow-y-auto p-4 space-y-5 text-xs text-slate-700">
        {!selectedNode && activeTab !== 'theme' ? (
          <div className="py-12 text-center text-slate-400">
            <p className="font-medium text-sm text-slate-600">Ningún nodo seleccionado</p>
            <p className="text-xs mt-1 text-slate-400">Haz clic en cualquier nodo para modificar sus propiedades.</p>
          </div>
        ) : (
          <>
            {/* CONTENT & TEXT TAB (Two Text Boxes: Título and Cuerpo, each with formatting) */}
            {activeTab === 'content' && selectedNode && (
              <div className="space-y-4">
                {/* 1. TÍTULO DEL NODO */}
                <div className="bg-slate-50/70 border border-slate-200 rounded-xl p-3 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <label className="font-semibold text-slate-800 flex items-center gap-1.5 text-xs">
                      <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                      Título del Nodo
                    </label>
                    <span className="text-[10px] text-slate-400 font-normal">Texto principal</span>
                  </div>

                  {/* Title Textarea */}
                  <textarea
                    value={selectedNode.text}
                    onChange={(e) => onUpdateNode(selectedNode.id, { text: e.target.value })}
                    rows={2}
                    className="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs font-medium text-slate-800 outline-none focus:border-blue-500 resize-y shadow-2xs"
                    placeholder="Escribe el título..."
                  />

                  {/* Title Formatting Controls */}
                  <div className="space-y-2 pt-1 border-t border-slate-200/80">
                    <div className="flex items-center justify-between text-[11px] text-slate-500 font-medium">
                      <span>Formato del Título</span>
                    </div>

                    <div className="flex items-center gap-1.5 flex-wrap">
                      {/* Bold / Italic */}
                      <div className="flex rounded-lg border border-slate-200 bg-white overflow-hidden shadow-2xs">
                        <button
                          title="Negrita"
                          onClick={() => onUpdateNode(selectedNode.id, { bold: !selectedNode.bold })}
                          className={`p-1.5 transition-colors ${
                            selectedNode.bold ? 'bg-blue-100 text-blue-700 font-bold' : 'hover:bg-slate-50 text-slate-600'
                          }`}
                        >
                          <Bold className="w-3.5 h-3.5" />
                        </button>
                        <button
                          title="Cursiva"
                          onClick={() => onUpdateNode(selectedNode.id, { italic: !selectedNode.italic })}
                          className={`p-1.5 transition-colors border-l border-slate-200 ${
                            selectedNode.italic ? 'bg-blue-100 text-blue-700' : 'hover:bg-slate-50 text-slate-600'
                          }`}
                        >
                          <Italic className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Alignment */}
                      <div className="flex rounded-lg border border-slate-200 bg-white overflow-hidden shadow-2xs">
                        <button
                          title="Alinear a la izquierda"
                          onClick={() => onUpdateNode(selectedNode.id, { textAlign: 'left' })}
                          className={`p-1.5 transition-colors ${
                            (selectedNode.textAlign || 'left') === 'left' ? 'bg-blue-100 text-blue-700' : 'hover:bg-slate-50 text-slate-600'
                          }`}
                        >
                          <AlignLeft className="w-3.5 h-3.5" />
                        </button>
                        <button
                          title="Alinear al centro"
                          onClick={() => onUpdateNode(selectedNode.id, { textAlign: 'center' })}
                          className={`p-1.5 transition-colors border-l border-slate-200 ${
                            selectedNode.textAlign === 'center' ? 'bg-blue-100 text-blue-700' : 'hover:bg-slate-50 text-slate-600'
                          }`}
                        >
                          <AlignCenter className="w-3.5 h-3.5" />
                        </button>
                        <button
                          title="Alinear a la derecha"
                          onClick={() => onUpdateNode(selectedNode.id, { textAlign: 'right' })}
                          className={`p-1.5 transition-colors border-l border-slate-200 ${
                            selectedNode.textAlign === 'right' ? 'bg-blue-100 text-blue-700' : 'hover:bg-slate-50 text-slate-600'
                          }`}
                        >
                          <AlignRight className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Font Size */}
                      <select
                        value={selectedNode.fontSize || 14}
                        onChange={(e) => onUpdateNode(selectedNode.id, { fontSize: parseInt(e.target.value, 10) })}
                        className="flex-1 bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 font-medium outline-none focus:border-blue-500 shadow-2xs"
                      >
                        <option value={12}>12 px</option>
                        <option value={14}>14 px</option>
                        <option value={16}>16 px</option>
                        <option value={18}>18 px</option>
                        <option value={20}>20 px</option>
                        <option value={24}>24 px</option>
                      </select>
                    </div>

                    {/* Title Color */}
                    <div className="flex items-center gap-1.5">
                      <span className="text-[11px] text-slate-500">Color:</span>
                      <input
                        type="color"
                        value={selectedNode.textColor || '#0f172a'}
                        onChange={(e) => onUpdateNode(selectedNode.id, { textColor: e.target.value })}
                        className="w-5 h-5 rounded border border-slate-200 cursor-pointer p-0 shadow-2xs"
                        title="Seleccionar color personalizado"
                      />
                      <div className="flex items-center gap-1 flex-1">
                        {TEXT_COLOR_PRESETS.map((c) => (
                          <button
                            key={c}
                            style={{ backgroundColor: c }}
                            onClick={() => onUpdateNode(selectedNode.id, { textColor: c })}
                            className="w-4 h-4 rounded-full border border-slate-300 shadow-2xs hover:scale-110 transition-transform"
                            title={c}
                          />
                        ))}
                      </div>
                      <button
                        onClick={() => onUpdateNode(selectedNode.id, { textColor: undefined })}
                        className="text-[10px] text-slate-400 hover:text-slate-700 underline"
                      >
                        Auto
                      </button>
                    </div>
                  </div>
                </div>

                {/* 2. CUERPO DEL NODO */}
                <div className="bg-slate-50/70 border border-slate-200 rounded-xl p-3 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <label className="font-semibold text-slate-800 flex items-center gap-1.5 text-xs">
                      <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                      Cuerpo del Nodo
                    </label>
                    <span className="text-[10px] text-slate-400 font-normal">Explicación del título</span>
                  </div>

                  {/* Body Textarea */}
                  <textarea
                    value={selectedNode.body || ''}
                    onChange={(e) => onUpdateNode(selectedNode.id, { body: e.target.value || undefined })}
                    rows={3}
                    className="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs font-normal text-slate-700 outline-none focus:border-blue-500 resize-y shadow-2xs"
                    placeholder="Escribe una pequeña explicación o detalle sobre el título del nodo..."
                  />

                  {/* Body Formatting Controls */}
                  <div className="space-y-2 pt-1 border-t border-slate-200/80">
                    <div className="flex items-center justify-between text-[11px] text-slate-500 font-medium">
                      <span>Formato del Cuerpo</span>
                    </div>

                    <div className="flex items-center gap-1.5 flex-wrap">
                      {/* Bold / Italic */}
                      <div className="flex rounded-lg border border-slate-200 bg-white overflow-hidden shadow-2xs">
                        <button
                          title="Cuerpo en Negrita"
                          onClick={() => onUpdateNode(selectedNode.id, { bodyBold: !selectedNode.bodyBold })}
                          className={`p-1.5 transition-colors ${
                            selectedNode.bodyBold ? 'bg-emerald-100 text-emerald-700 font-bold' : 'hover:bg-slate-50 text-slate-600'
                          }`}
                        >
                          <Bold className="w-3.5 h-3.5" />
                        </button>
                        <button
                          title="Cuerpo en Cursiva"
                          onClick={() => onUpdateNode(selectedNode.id, { bodyItalic: !selectedNode.bodyItalic })}
                          className={`p-1.5 transition-colors border-l border-slate-200 ${
                            selectedNode.bodyItalic ? 'bg-emerald-100 text-emerald-700' : 'hover:bg-slate-50 text-slate-600'
                          }`}
                        >
                          <Italic className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Alignment */}
                      <div className="flex rounded-lg border border-slate-200 bg-white overflow-hidden shadow-2xs">
                        <button
                          title="Alinear cuerpo a la izquierda"
                          onClick={() => onUpdateNode(selectedNode.id, { bodyAlign: 'left' })}
                          className={`p-1.5 transition-colors ${
                            (selectedNode.bodyAlign || 'left') === 'left' ? 'bg-emerald-100 text-emerald-700' : 'hover:bg-slate-50 text-slate-600'
                          }`}
                        >
                          <AlignLeft className="w-3.5 h-3.5" />
                        </button>
                        <button
                          title="Alinear cuerpo al centro"
                          onClick={() => onUpdateNode(selectedNode.id, { bodyAlign: 'center' })}
                          className={`p-1.5 transition-colors border-l border-slate-200 ${
                            selectedNode.bodyAlign === 'center' ? 'bg-emerald-100 text-emerald-700' : 'hover:bg-slate-50 text-slate-600'
                          }`}
                        >
                          <AlignCenter className="w-3.5 h-3.5" />
                        </button>
                        <button
                          title="Alinear cuerpo a la derecha"
                          onClick={() => onUpdateNode(selectedNode.id, { bodyAlign: 'right' })}
                          className={`p-1.5 transition-colors border-l border-slate-200 ${
                            selectedNode.bodyAlign === 'right' ? 'bg-emerald-100 text-emerald-700' : 'hover:bg-slate-50 text-slate-600'
                          }`}
                        >
                          <AlignRight className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Body Font Size */}
                      <select
                        value={selectedNode.bodyFontSize || 12}
                        onChange={(e) => onUpdateNode(selectedNode.id, { bodyFontSize: parseInt(e.target.value, 10) })}
                        className="flex-1 bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 font-medium outline-none focus:border-blue-500 shadow-2xs"
                      >
                        <option value={10}>10 px</option>
                        <option value={11}>11 px</option>
                        <option value={12}>12 px</option>
                        <option value={13}>13 px</option>
                        <option value={14}>14 px</option>
                        <option value={16}>16 px</option>
                      </select>
                    </div>

                    {/* Body Color */}
                    <div className="flex items-center gap-1.5">
                      <span className="text-[11px] text-slate-500">Color:</span>
                      <input
                        type="color"
                        value={selectedNode.bodyColor || '#475569'}
                        onChange={(e) => onUpdateNode(selectedNode.id, { bodyColor: e.target.value })}
                        className="w-5 h-5 rounded border border-slate-200 cursor-pointer p-0 shadow-2xs"
                        title="Seleccionar color personalizado del cuerpo"
                      />
                      <div className="flex items-center gap-1 flex-1">
                        {TEXT_COLOR_PRESETS.map((c) => (
                          <button
                            key={c}
                            style={{ backgroundColor: c }}
                            onClick={() => onUpdateNode(selectedNode.id, { bodyColor: c })}
                            className="w-4 h-4 rounded-full border border-slate-300 shadow-2xs hover:scale-110 transition-transform"
                            title={c}
                          />
                        ))}
                      </div>
                      <button
                        onClick={() => onUpdateNode(selectedNode.id, { bodyColor: undefined })}
                        className="text-[10px] text-slate-400 hover:text-slate-700 underline"
                      >
                        Auto
                      </button>
                    </div>
                  </div>
                </div>

                {/* 3. METADATA: Enlace, Progreso y Etiquetas */}
                <div className="space-y-3 pt-2">
                  {/* Hyperlink */}
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Enlace Web o Correo</label>
                    <div className="flex items-center gap-1.5">
                      <input
                        type="url"
                        value={selectedNode.link || ''}
                        onChange={(e) => onUpdateNode(selectedNode.id, { link: e.target.value || undefined })}
                        placeholder="https://ejemplo.com"
                        className="flex-1 bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs outline-none focus:border-blue-500"
                      />
                      {selectedNode.link && (
                        <a
                          href={selectedNode.link}
                          target="_blank"
                          rel="noreferrer"
                          className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </a>
                      )}
                    </div>
                  </div>

                  {/* Progress Percentage */}
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Progreso de Tarea</label>
                    <div className="flex items-center gap-1.5">
                      {[undefined, 0, 25, 50, 75, 100].map((p) => (
                        <button
                          key={String(p)}
                          onClick={() => onUpdateNode(selectedNode.id, { progress: p })}
                          className={`flex-1 py-1.5 rounded-lg border text-xs font-semibold transition-colors ${
                            selectedNode.progress === p
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                          }`}
                        >
                          {p === undefined ? '—' : `${p}%`}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Tags */}
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Etiquetas (#Tags en parte baja)</label>
                    <div className="flex items-center gap-1.5 mb-2">
                      <input
                        type="text"
                        value={newTagInput}
                        onChange={(e) => setNewTagInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleAddTag()}
                        placeholder="Nueva etiqueta..."
                        className="flex-1 bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs outline-none focus:border-blue-500"
                      />
                      <button
                        onClick={handleAddTag}
                        className="px-2.5 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-1"
                      >
                        <Plus className="w-3.5 h-3.5" /> Agregar
                      </button>
                    </div>

                    {selectedNode.tags && selectedNode.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {selectedNode.tags.map((t) => (
                          <span
                            key={t}
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-medium text-[11px]"
                          >
                            #{t}
                            <button
                              onClick={() => handleRemoveTag(t)}
                              className="hover:text-red-500 ml-0.5"
                            >
                              ×
                            </button>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* FORMAT TAB */}
            {activeTab === 'format' && selectedNode && (
              <div className="space-y-4">
                {/* Node Shape */}
                <div>
                  <label className="block font-semibold text-slate-700 mb-1.5">Forma del Nodo</label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {[
                      { id: 'bubble', label: 'Burbuja' },
                      { id: 'fork', label: 'Horquilla' },
                      { id: 'rectangle', label: 'Rectángulo' },
                      { id: 'oval', label: 'Óvalo' },
                      { id: 'hexagon', label: 'Hexágono' },
                    ].map((s) => (
                      <button
                        key={s.id}
                        onClick={() => handleShapeChange(s.id as NodeShape)}
                        className={`px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-colors ${
                          (selectedNode.shape || 'bubble') === s.id
                            ? 'bg-blue-50 border-blue-500 text-blue-600 font-semibold'
                            : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                        }`}
                      >
                        {s.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Background Color */}
                <div>
                  <label className="block font-semibold text-slate-700 mb-1.5">Color de Fondo del Nodo</label>
                  <div className="flex items-center gap-2 mb-2">
                    <input
                      type="color"
                      value={selectedNode.color || '#ffffff'}
                      onChange={(e) => onUpdateNode(selectedNode.id, { color: e.target.value })}
                      className="w-7 h-7 rounded border border-slate-200 cursor-pointer p-0"
                    />
                    <button
                      onClick={() => onUpdateNode(selectedNode.id, { color: undefined })}
                      className="text-[11px] text-slate-500 hover:text-slate-800 underline"
                    >
                      Por defecto
                    </button>
                  </div>
                  <div className="grid grid-cols-8 gap-1">
                    {COLOR_PRESETS.map((c) => (
                      <button
                        key={c}
                        style={{ backgroundColor: c }}
                        onClick={() => onUpdateNode(selectedNode.id, { color: c })}
                        className="w-6 h-6 rounded-md border border-slate-300 shadow-2xs hover:scale-110 transition-transform"
                      />
                    ))}
                  </div>
                </div>

                {/* Border Options */}
                <div>
                  <label className="block font-semibold text-slate-700 mb-1.5">Borde del Nodo</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={selectedNode.borderColor || '#cbd5e1'}
                      onChange={(e) => onUpdateNode(selectedNode.id, { borderColor: e.target.value })}
                      className="w-7 h-7 rounded border border-slate-200 cursor-pointer p-0"
                    />
                    <select
                      value={selectedNode.borderWidth !== undefined ? selectedNode.borderWidth : 1.5}
                      onChange={(e) => onUpdateNode(selectedNode.id, { borderWidth: parseFloat(e.target.value) })}
                      className="flex-1 bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 outline-none"
                    >
                      <option value={0}>Sin borde</option>
                      <option value={1}>Fino (1px)</option>
                      <option value={1.5}>Estándar (1.5px)</option>
                      <option value={2}>Medio (2px)</option>
                      <option value={3}>Grueso (3px)</option>
                    </select>
                  </div>
                </div>

                {/* Edge Curve Style */}
                <div>
                  <label className="block font-semibold text-slate-700 mb-1.5">Estilo de Rama Conectora</label>
                  <select
                    value={selectedNode.edgeStyle || currentTheme.edgeStyle || 'bezier'}
                    onChange={(e) => onUpdateNode(selectedNode.id, { edgeStyle: e.target.value as EdgeStyle })}
                    className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 font-medium outline-none focus:border-blue-500"
                  >
                    <option value="bezier">Curva Suave (Bézier)</option>
                    <option value="linear">Línea Recta</option>
                    <option value="sharp">Escuadra / Ángulo Recto</option>
                  </select>
                </div>
              </div>
            )}

            {/* NOTES TAB */}
            {activeTab === 'notes' && selectedNode && (
              <div className="space-y-3">
                <label className="block font-semibold text-slate-700">
                  Nota Detallada (Markdown)
                </label>
                <textarea
                  value={selectedNode.note || ''}
                  onChange={(e) => onUpdateNode(selectedNode.id, { note: e.target.value || undefined })}
                  rows={10}
                  className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-xs font-mono text-slate-800 outline-none focus:border-blue-500 resize-y"
                  placeholder="# Título de nota&#10;&#10;Escribe notas detalladas con soporte de listas, texto enriquecido o enlaces..."
                />
                <p className="text-[11px] text-slate-400">
                  Las notas se guardan automáticamente y son visibles al pasar el ratón por el icono del nodo.
                </p>
              </div>
            )}

            {/* ICONS TAB */}
            {activeTab === 'icons' && selectedNode && (
              <div className="space-y-3.5">
                {/* Active Icons on Selected Node */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="font-semibold text-slate-700 text-xs flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                      Iconos en este Nodo
                    </label>
                    {selectedNode.icons && selectedNode.icons.length > 0 && (
                      <button
                        onClick={() => onUpdateNode(selectedNode.id, { icons: [] })}
                        className="text-[10px] text-red-500 hover:text-red-700 underline"
                      >
                        Quitar todos
                      </button>
                    )}
                  </div>

                  {selectedNode.icons && selectedNode.icons.length > 0 ? (
                    <div className="flex flex-wrap gap-1.5 p-2 bg-slate-50 border border-slate-200 rounded-xl">
                      {selectedNode.icons.map((icId) => (
                        <span
                          key={icId}
                          className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-white border border-blue-200 text-blue-900 text-xs shadow-2xs"
                        >
                          <span className="w-4 h-4 flex items-center justify-center">
                            {renderNodeIcon(icId, 'w-3.5 h-3.5 text-blue-600')}
                          </span>
                          <span className="text-[11px] font-mono font-medium">{icId}</span>
                          <button
                            onClick={() => handleToggleIcon(icId)}
                            className="text-slate-400 hover:text-red-600 ml-0.5"
                            title="Quitar icono"
                          >
                            ×
                          </button>
                        </span>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[11px] text-slate-400 italic bg-slate-50/70 p-2 rounded-lg border border-dashed border-slate-200">
                      Sin iconos aplicados. Selecciona abajo o abre el explorador.
                    </p>
                  )}
                </div>

                {/* Open Full 500+ Vector Icon Browser */}
                {onOpenIconPackModal && (
                  <button
                    onClick={onOpenIconPackModal}
                    className="w-full py-2 px-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 shadow-xs transition-all"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Explorar los 500+ Iconos SVG</span>
                    <Maximize2 className="w-3.5 h-3.5 opacity-80" />
                  </button>
                )}

                {/* Real-time Search */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={iconSearchQuery}
                    onChange={(e) => setIconSearchQuery(e.target.value)}
                    placeholder="Buscar en 500+ iconos..."
                    className="w-full bg-white border border-slate-200 rounded-lg pl-8 pr-7 py-1.5 text-xs text-slate-700 outline-none focus:border-blue-500 placeholder:text-slate-400 shadow-2xs"
                  />
                  {iconSearchQuery && (
                    <button
                      onClick={() => setIconSearchQuery('')}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 text-xs"
                    >
                      ×
                    </button>
                  )}
                </div>

                {/* Category Pills */}
                <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none text-[11px]">
                  <button
                    onClick={() => setIconCategory('all')}
                    className={`px-2 py-1 rounded-md whitespace-nowrap transition-colors ${
                      iconCategory === 'all'
                        ? 'bg-slate-900 text-white font-medium'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    Todos ({TOTAL_VECTOR_ICONS_COUNT})
                  </button>
                  {VECTOR_ICON_CATEGORIES.map((cat) => {
                    const isSelected = iconCategory === cat.id;
                    return (
                      <button
                        key={cat.id}
                        onClick={() => setIconCategory(cat.id)}
                        className={`px-2 py-1 rounded-md whitespace-nowrap transition-colors ${
                          isSelected
                            ? 'bg-blue-600 text-white font-medium'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        {cat.name.split('&')[0].trim()}
                      </button>
                    );
                  })}
                </div>

                {/* Icon Grid */}
                <div className="max-h-72 overflow-y-auto pr-1">
                  {filteredVectorIcons.length === 0 ? (
                    <div className="text-center py-6 text-slate-400 text-xs">
                      No se encontraron iconos para "{iconSearchQuery}"
                    </div>
                  ) : (
                    <div className="grid grid-cols-4 gap-1.5">
                      {filteredVectorIcons.map((ic) => {
                        const IconComponent = ic.icon;
                        const isSelected = selectedNode.icons?.includes(ic.id);
                        return (
                          <button
                            key={ic.id}
                            title={`${ic.name} (${ic.id})`}
                            onClick={() => handleToggleIcon(ic.id)}
                            className={`flex flex-col items-center justify-center p-2 rounded-xl border transition-all text-center group ${
                              isSelected
                                ? 'bg-blue-50 border-blue-500 shadow-2xs scale-105 ring-1 ring-blue-400'
                                : 'bg-white border-slate-200 hover:bg-slate-50 hover:border-slate-300'
                            }`}
                          >
                            <div className="w-5 h-5 flex items-center justify-center mb-1 text-slate-700 group-hover:text-blue-600 group-hover:scale-110 transition-transform">
                              <IconComponent className="w-4 h-4" />
                            </div>
                            <span className="text-[9px] text-slate-600 truncate max-w-full font-medium">
                              {ic.name}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* CLOUDS TAB */}
            {activeTab === 'clouds' && selectedNode && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <label className="font-semibold text-slate-700">Nube de Agrupación</label>
                  <input
                    type="checkbox"
                    checked={Boolean(selectedNode.cloud?.enabled)}
                    onChange={(e) =>
                      onUpdateNode(selectedNode.id, {
                        cloud: e.target.checked
                          ? { enabled: true, color: 'rgba(59, 130, 246, 0.1)', shape: 'round-rectangle' }
                          : undefined,
                      })
                    }
                    className="w-4 h-4 accent-blue-600 rounded cursor-pointer"
                  />
                </div>

                {selectedNode.cloud?.enabled && (
                  <>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1.5">Color de la Nube</label>
                      <div className="grid grid-cols-4 gap-2">
                        {[
                          'rgba(59, 130, 246, 0.12)',
                          'rgba(34, 197, 94, 0.12)',
                          'rgba(245, 158, 11, 0.12)',
                          'rgba(236, 72, 153, 0.12)',
                          'rgba(168, 85, 247, 0.12)',
                          'rgba(6, 182, 212, 0.12)',
                          'rgba(239, 68, 68, 0.12)',
                          'rgba(100, 116, 139, 0.12)',
                        ].map((col) => (
                          <button
                            key={col}
                            style={{ backgroundColor: col }}
                            onClick={() =>
                              onUpdateNode(selectedNode.id, {
                                cloud: { ...selectedNode.cloud!, color: col },
                              })
                            }
                            className="h-8 rounded-lg border border-slate-300 shadow-2xs hover:scale-105 transition-transform"
                          />
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 mb-1.5">Forma de la Nube</label>
                      <select
                        value={selectedNode.cloud.shape || 'round-rectangle'}
                        onChange={(e) =>
                          onUpdateNode(selectedNode.id, {
                            cloud: { ...selectedNode.cloud!, shape: e.target.value as any },
                          })
                        }
                        className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 outline-none focus:border-blue-500"
                      >
                        <option value="round-rectangle">Rectángulo Redondeado</option>
                        <option value="arc">Burbuja Suave / Arco</option>
                      </select>
                    </div>
                  </>
                )}
              </div>
            )}

            {/* THEME & MAP TAB */}
            {activeTab === 'theme' && (
              <div className="space-y-4">
                {/* Global Expand / Collapse All Controls */}
                <div className="flex items-center justify-between px-1 text-slate-500">
                  <span className="text-[11px] font-medium text-slate-500">Ajustes Generales del Mapa</span>
                  <div className="flex items-center gap-1.5 text-[10px]">
                    <button
                      type="button"
                      onClick={() => handleExpandAllMapSections(true)}
                      className="text-blue-600 hover:text-blue-800 hover:underline cursor-pointer font-medium"
                    >
                      Expandir todo
                    </button>
                    <span>•</span>
                    <button
                      type="button"
                      onClick={() => handleExpandAllMapSections(false)}
                      className="text-slate-500 hover:text-slate-700 hover:underline cursor-pointer font-medium"
                    >
                      Contraer todo
                    </button>
                  </div>
                </div>

                {/* 1. PANEL: TIPO DE ENLACES / CONEXIONES */}
                <div className="bg-slate-50/80 border border-slate-200/90 rounded-2xl shadow-2xs overflow-hidden transition-all">
                  {/* Collapsible Header */}
                  <button
                    type="button"
                    onClick={() => toggleMapSection('edges')}
                    className="w-full px-3.5 py-3 flex items-center justify-between text-left hover:bg-slate-100/70 transition-colors cursor-pointer select-none"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-6 h-6 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
                        <GitFork className="w-3.5 h-3.5 rotate-90" />
                      </div>
                      <div className="min-w-0">
                        <label className="font-semibold text-slate-800 text-xs block truncate cursor-pointer">
                          Tipo de Enlaces
                        </label>
                        <span className="text-[10px] text-slate-400 font-normal block truncate">
                          Estilo de líneas y grosor de ramas
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {showAppliedToast && (
                        <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded-full animate-in fade-in">
                          <Check className="w-3 h-3" /> Aplicado
                        </span>
                      )}
                      <ChevronDown
                        className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${
                          mapSectionsOpen.edges ? 'rotate-0' : '-rotate-90'
                        }`}
                      />
                    </div>
                  </button>

                  {/* Collapsible Body */}
                  {mapSectionsOpen.edges && (
                    <div className="px-3.5 pb-3.5 pt-1 space-y-3.5 border-t border-slate-200/60 animate-in fade-in duration-150">
                      {/* Edge Style Selector Grid */}
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1.5">
                          Forma de la Conexión
                        </label>
                        <div className="grid grid-cols-2 gap-1.5">
                          {[
                            {
                              id: 'bezier' as EdgeStyle,
                              name: 'Curva Bézier',
                              desc: 'Suave & orgánica',
                              svg: (
                                <svg className="w-8 h-5 text-blue-500" viewBox="0 0 32 20" fill="none">
                                  <circle cx="4" cy="16" r="2.5" fill="currentColor" />
                                  <circle cx="28" cy="4" r="2.5" fill="currentColor" />
                                  <path d="M 4 16 C 16 16, 16 4, 28 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                                </svg>
                              ),
                            },
                            {
                              id: 'linear' as EdgeStyle,
                              name: 'Línea Recta',
                              desc: 'Conexión directa',
                              svg: (
                                <svg className="w-8 h-5 text-indigo-500" viewBox="0 0 32 20" fill="none">
                                  <circle cx="4" cy="16" r="2.5" fill="currentColor" />
                                  <circle cx="28" cy="4" r="2.5" fill="currentColor" />
                                  <path d="M 4 16 L 28 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                                </svg>
                              ),
                            },
                            {
                              id: 'sharp' as EdgeStyle,
                              name: 'Ángulo Recto',
                              desc: 'Ortogonal 90°',
                              svg: (
                                <svg className="w-8 h-5 text-emerald-500" viewBox="0 0 32 20" fill="none">
                                  <circle cx="4" cy="16" r="2.5" fill="currentColor" />
                                  <circle cx="28" cy="4" r="2.5" fill="currentColor" />
                                  <path d="M 4 16 L 16 16 L 16 4 L 28 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                </svg>
                              ),
                            },
                            {
                              id: 'horizontal' as EdgeStyle,
                              name: 'Escalón',
                              desc: 'Rama Freeplane',
                              svg: (
                                <svg className="w-8 h-5 text-amber-500" viewBox="0 0 32 20" fill="none">
                                  <circle cx="4" cy="16" r="2.5" fill="currentColor" />
                                  <circle cx="28" cy="4" r="2.5" fill="currentColor" />
                                  <path d="M 4 16 L 10 16 L 10 4 L 28 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                </svg>
                              ),
                            },
                          ].map((item) => {
                            const isSelected = currentMapEdgeStyle === item.id;
                            return (
                              <button
                                key={item.id}
                                onClick={() => {
                                  if (onUpdateMapEdgeStyle) onUpdateMapEdgeStyle(item.id);
                                }}
                                className={`p-2 rounded-xl border text-left flex flex-col justify-between gap-1 transition-all ${
                                  isSelected
                                    ? 'bg-blue-50/90 border-blue-500 ring-2 ring-blue-500/20 text-blue-900 shadow-2xs'
                                    : 'bg-white border-slate-200 hover:border-slate-300 text-slate-700 hover:bg-slate-50/80'
                                }`}
                              >
                                <div className="flex items-center justify-between w-full">
                                  <span className="font-semibold text-[11px]">{item.name}</span>
                                  {isSelected && <Check className="w-3 h-3 text-blue-600 shrink-0" />}
                                </div>
                                <div className="flex items-center justify-between">
                                  <span className="text-[9px] text-slate-400">{item.desc}</span>
                                  <div className="shrink-0">{item.svg}</div>
                                </div>
                              </button>
                            );
                          })}
                        </div>

                        {/* Hidden / None option button */}
                        <button
                          onClick={() => {
                            if (onUpdateMapEdgeStyle) onUpdateMapEdgeStyle('hidden');
                          }}
                          className={`w-full mt-1.5 py-1.5 px-2.5 rounded-lg border text-xs flex items-center justify-between transition-colors ${
                            currentMapEdgeStyle === 'hidden'
                              ? 'bg-blue-50 border-blue-500 text-blue-700 font-semibold'
                              : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                          }`}
                        >
                          <span className="text-[11px]">Ocultar todas las líneas (Sin enlaces)</span>
                          {currentMapEdgeStyle === 'hidden' && <Check className="w-3 h-3 text-blue-600" />}
                        </button>
                      </div>

                      {/* Perfil y Variación de Grosor (Principio, Medio y Fin) */}
                      <div className="pt-2 border-t border-slate-200/70">
                        <div className="flex items-center justify-between mb-1.5">
                          <div>
                            <label className="text-[11px] font-semibold text-slate-700 block">
                              Forma de Grosor (Principio, Medio y Fin)
                            </label>
                            <span className="text-[9.5px] text-slate-400 font-normal">
                              Variación del trazo en origen, centro y destino
                            </span>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-1.5">
                          {[
                            {
                              id: 'uniform' as EdgeProfile,
                              name: 'Uniforme',
                              desc: 'Grosor continuo parejo',
                              svg: (
                                <svg className="w-9 h-4.5 text-blue-500" viewBox="0 0 36 18" fill="currentColor">
                                  <rect x="2" y="7" width="32" height="4" rx="2" />
                                </svg>
                              ),
                            },
                            {
                              id: 'tapered' as EdgeProfile,
                              name: 'Cónico (1 Punta)',
                              desc: 'Ancho en inicio, fino al fin',
                              svg: (
                                <svg className="w-9 h-4.5 text-indigo-500" viewBox="0 0 36 18" fill="currentColor">
                                  <path d="M 2 3 L 34 8.5 A 1 1 0 0 1 34 9.5 L 2 15 Z" />
                                </svg>
                              ),
                            },
                            {
                              id: 'spindle' as EdgeProfile,
                              name: 'Ancho al Medio',
                              desc: 'Fino en puntas, grueso al centro',
                              svg: (
                                <svg className="w-9 h-4.5 text-emerald-500" viewBox="0 0 36 18" fill="currentColor">
                                  <path d="M 2 9 C 12 2.5, 24 2.5, 34 9 C 24 15.5, 12 15.5, 2 9 Z" />
                                </svg>
                              ),
                            },
                            {
                              id: 'hourglass' as EdgeProfile,
                              name: 'Ancho en Puntas',
                              desc: 'Ancho en puntas, fino al centro',
                              svg: (
                                <svg className="w-9 h-4.5 text-purple-500" viewBox="0 0 36 18" fill="currentColor">
                                  <path d="M 2 3 C 14 7.5, 22 7.5, 34 3 L 34 15 C 22 10.5, 14 10.5, 2 15 Z" />
                                </svg>
                              ),
                            },
                          ].map((item) => {
                            const isSelected = currentMapEdgeProfile === item.id;
                            return (
                              <button
                                key={item.id}
                                onClick={() => {
                                  if (onUpdateMapEdgeProfile) onUpdateMapEdgeProfile(item.id);
                                }}
                                className={`p-2 rounded-xl border text-left flex flex-col justify-between gap-1 transition-all ${
                                  isSelected
                                    ? 'bg-indigo-50/90 border-indigo-500 ring-2 ring-indigo-500/20 text-indigo-950 shadow-2xs'
                                    : 'bg-white border-slate-200 hover:border-slate-300 text-slate-700 hover:bg-slate-50/80'
                                }`}
                              >
                                <div className="flex items-center justify-between w-full">
                                  <span className="font-semibold text-[11px]">{item.name}</span>
                                  {isSelected && <Check className="w-3 h-3 text-indigo-600 shrink-0" />}
                                </div>
                                <div className="flex items-center justify-between">
                                  <span className="text-[9px] text-slate-400 leading-tight">{item.desc}</span>
                                  <div className="shrink-0 pl-1">{item.svg}</div>
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Edge Width (Grosor) */}
                      <div className="pt-2 border-t border-slate-200/70">
                        <div className="flex items-center justify-between mb-1.5">
                          <label className="text-[11px] font-semibold text-slate-600">Grosor de Línea</label>
                          <span className="text-[10px] text-slate-400 font-medium">{currentMapEdgeWidth} px</span>
                        </div>
                        <div className="grid grid-cols-4 gap-1.5">
                          {[
                            { label: 'Fino', val: 1.5 },
                            { label: 'Estándar', val: 2.5 },
                            { label: 'Grueso', val: 4 },
                            { label: 'Extra', val: 6 },
                          ].map((gw) => (
                            <button
                              key={gw.val}
                              onClick={() => {
                                if (onUpdateMapEdgeWidth) onUpdateMapEdgeWidth(gw.val);
                              }}
                              className={`py-1.5 px-1 rounded-lg border text-center transition-all ${
                                currentMapEdgeWidth === gw.val
                                  ? 'bg-blue-50 border-blue-500 text-blue-700 font-bold shadow-2xs'
                                  : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50 text-[10px]'
                              }`}
                            >
                              <div className="flex justify-center mb-1">
                                <div
                                  style={{ height: `${Math.min(gw.val, 4)}px` }}
                                  className={`w-6 rounded-full ${
                                    currentMapEdgeWidth === gw.val ? 'bg-blue-600' : 'bg-slate-400'
                                  }`}
                                />
                              </div>
                              <span className="text-[10px]">{gw.label}</span>
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Line Pattern / Dashing (Patrón de Trazo) */}
                      <div className="pt-2 border-t border-slate-200/70">
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1.5">
                          Patrón de Trazo
                        </label>
                        <div className="grid grid-cols-3 gap-1.5">
                          {[
                            { id: 'solid', label: 'Continuo', pattern: '━━━━━' },
                            { id: 'dashed', label: 'Discontinuo', pattern: '╍ ╍ ╍' },
                            { id: 'dotted', label: 'Punteado', pattern: '• • • •' },
                          ].map((pat) => (
                            <button
                              key={pat.id}
                              onClick={() => {
                                if (onUpdateMapEdgeDash) onUpdateMapEdgeDash(pat.id as any);
                              }}
                              className={`py-1.5 px-2 rounded-lg border text-center transition-all ${
                                currentMapEdgeDash === pat.id
                                  ? 'bg-blue-50 border-blue-500 text-blue-700 font-semibold shadow-2xs'
                                  : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                              }`}
                            >
                              <div className="text-[11px] leading-tight font-mono text-slate-500 mb-0.5">{pat.pattern}</div>
                              <span className="text-[10px]">{pat.label}</span>
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Edge Color (Multicolor vs Custom Fixed Color) */}
                      <div className="pt-2 border-t border-slate-200/70 space-y-2">
                        <div className="flex items-center justify-between">
                          <label className="text-[11px] font-semibold text-slate-600">Color de los Enlaces</label>
                          <button
                            onClick={() => {
                              if (onUpdateMapEdgeColor) onUpdateMapEdgeColor(undefined);
                            }}
                            className={`text-[10px] px-2 py-0.5 rounded-full border transition-colors ${
                              !currentMapEdgeColor
                                ? 'bg-blue-100 border-blue-200 text-blue-700 font-semibold'
                                : 'border-slate-200 text-slate-500 hover:bg-slate-100'
                            }`}
                          >
                            Multicolor por Rama
                          </button>
                        </div>

                        <div className="flex items-center gap-1.5 flex-wrap">
                          {[
                            '#3b82f6', '#2563eb', '#10b981', '#059669',
                            '#f59e0b', '#ea580c', '#ef4444', '#8b5cf6',
                            '#06b6d4', '#475569', '#0f172a', '#64748b'
                          ].map((c) => (
                            <button
                              key={c}
                              style={{ backgroundColor: c }}
                              onClick={() => {
                                if (onUpdateMapEdgeColor) onUpdateMapEdgeColor(c);
                              }}
                              className={`w-6 h-6 rounded-full border transition-transform ${
                                currentMapEdgeColor === c
                                  ? 'ring-2 ring-blue-500 scale-110 border-white shadow-xs'
                                  : 'border-white hover:scale-105'
                              }`}
                            />
                          ))}
                        </div>
                      </div>

                      {/* Apply to all button */}
                      <button
                        onClick={() => {
                          handleApplyToAll(currentMapEdgeStyle);
                          handleApplyProfileToAll(currentMapEdgeProfile);
                        }}
                        className="w-full mt-2 py-2 px-3 rounded-xl bg-slate-800 text-white hover:bg-slate-900 font-semibold text-xs flex items-center justify-center gap-1.5 shadow-2xs transition-all active:scale-98 cursor-pointer"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                        <span>Aplicar estilo y perfil a todas las ramas</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* 2. ENLACE DEL NODO SELECCIONADO (Si hay un nodo activo) */}
                {selectedNode && selectedNode.parentId !== null && (
                  <div className="bg-blue-50/50 border border-blue-200/80 rounded-2xl shadow-2xs overflow-hidden transition-all">
                    {/* Collapsible Header */}
                    <button
                      type="button"
                      onClick={() => toggleMapSection('nodeEdge')}
                      className="w-full px-3.5 py-3 flex items-center justify-between text-left hover:bg-blue-100/40 transition-colors cursor-pointer select-none"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="w-6 h-6 rounded-lg bg-blue-200/70 text-blue-700 flex items-center justify-center shrink-0">
                          <Share2 className="w-3.5 h-3.5" />
                        </div>
                        <div className="min-w-0">
                          <span className="font-semibold text-slate-800 text-xs block truncate">
                            Enlace de este Nodo
                          </span>
                          <span className="text-[10px] text-blue-600/80 truncate block">
                            {selectedNode.text || 'Sin título'}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {(selectedNode.edgeStyle || selectedNode.edgeProfile || selectedNode.edgeColor || selectedNode.edgeWidth || selectedNode.edgeDash) && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onUpdateNode(selectedNode.id, {
                                edgeStyle: undefined,
                                edgeProfile: undefined,
                                edgeColor: undefined,
                                edgeWidth: undefined,
                                edgeDash: undefined,
                              });
                            }}
                            className="text-[10px] text-blue-600 hover:text-blue-800 flex items-center gap-1 hover:underline"
                          >
                            <RotateCcw className="w-2.5 h-2.5" /> Restablecer
                          </button>
                        )}
                        <ChevronDown
                          className={`w-4 h-4 text-blue-400 transition-transform duration-200 ${
                            mapSectionsOpen.nodeEdge ? 'rotate-0' : '-rotate-90'
                          }`}
                        />
                      </div>
                    </button>

                    {/* Collapsible Body */}
                    {mapSectionsOpen.nodeEdge && (
                      <div className="px-3.5 pb-3.5 pt-1 space-y-2.5 border-t border-blue-200/50 animate-in fade-in duration-150">
                        <div className="grid grid-cols-2 gap-1.5">
                          <select
                            value={selectedNode.edgeStyle || ''}
                            onChange={(e) =>
                              onUpdateNode(selectedNode.id, {
                                edgeStyle: e.target.value ? (e.target.value as EdgeStyle) : undefined,
                              })
                            }
                            className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 outline-none focus:border-blue-500"
                          >
                            <option value="">Forma heredada</option>
                            <option value="bezier">Curva Bézier</option>
                            <option value="linear">Línea Recta</option>
                            <option value="sharp">Ángulo Recto</option>
                            <option value="horizontal">Escalón</option>
                            <option value="hidden">Oculto</option>
                          </select>

                          <select
                            value={selectedNode.edgeProfile || ''}
                            onChange={(e) =>
                              onUpdateNode(selectedNode.id, {
                                edgeProfile: e.target.value ? (e.target.value as EdgeProfile) : undefined,
                              })
                            }
                            className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 outline-none focus:border-blue-500"
                          >
                            <option value="">Grosor heredado</option>
                            <option value="uniform">Uniforme</option>
                            <option value="tapered">Cónico (Ancho inicio)</option>
                            <option value="spindle">Ancho al medio</option>
                            <option value="hourglass">Ancho en puntas</option>
                          </select>
                        </div>

                        <div className="grid grid-cols-2 gap-1.5">
                          <select
                            value={selectedNode.edgeDash || ''}
                            onChange={(e) =>
                              onUpdateNode(selectedNode.id, {
                                edgeDash: e.target.value ? (e.target.value as any) : undefined,
                              })
                            }
                            className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 outline-none focus:border-blue-500"
                          >
                            <option value="">Trazo heredado</option>
                            <option value="solid">Continuo</option>
                            <option value="dashed">Discontinuo</option>
                            <option value="dotted">Punteado</option>
                          </select>

                          <select
                            value={selectedNode.edgeWidth ? String(selectedNode.edgeWidth) : ''}
                            onChange={(e) =>
                              onUpdateNode(selectedNode.id, {
                                edgeWidth: e.target.value ? Number(e.target.value) : undefined,
                              })
                            }
                            className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 outline-none focus:border-blue-500"
                          >
                            <option value="">Grosor base</option>
                            <option value="1.5">Fino (1.5 px)</option>
                            <option value="2.5">Estándar (2.5 px)</option>
                            <option value="4">Grueso (4.0 px)</option>
                            <option value="6">Extra (6.0 px)</option>
                          </select>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* 3. CONECTORES FLOTANTES & RELACIONES */}
                <div className="bg-slate-50/80 border border-slate-200/90 rounded-2xl shadow-2xs overflow-hidden transition-all">
                  {/* Collapsible Header */}
                  <button
                    type="button"
                    onClick={() => toggleMapSection('connectors')}
                    className="w-full px-3.5 py-3 flex items-center justify-between text-left hover:bg-slate-100/70 transition-colors cursor-pointer select-none"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-6 h-6 rounded-lg bg-cyan-100 text-cyan-700 flex items-center justify-center shrink-0">
                        <LinkIcon className="w-3.5 h-3.5" />
                      </div>
                      <div className="min-w-0">
                        <label className="font-semibold text-slate-800 text-xs block truncate cursor-pointer">
                          Conectores Cruzados
                        </label>
                        <span className="text-[10px] text-slate-400 font-normal block truncate">
                          {mindMap?.connectors?.length || 0} relación(es) libre(s)
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (onOpenConnectorModal) onOpenConnectorModal(selectedNode?.id);
                        }}
                        className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cyan-600 text-white hover:bg-cyan-700 text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                      >
                        <Plus className="w-3 h-3" /> Nuevo
                      </button>
                      <ChevronDown
                        className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${
                          mapSectionsOpen.connectors ? 'rotate-0' : '-rotate-90'
                        }`}
                      />
                    </div>
                  </button>

                  {/* Collapsible Body */}
                  {mapSectionsOpen.connectors && (
                    <div className="px-3.5 pb-3.5 pt-1 space-y-2.5 border-t border-slate-200/60 animate-in fade-in duration-150">
                      {mindMap?.connectors && mindMap.connectors.length > 0 ? (
                        <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                          {mindMap.connectors.map((conn) => {
                            const fromNode = mindMap.nodes[conn.fromId];
                            const toNode = mindMap.nodes[conn.toId];
                            return (
                              <div
                                key={conn.id}
                                className="flex items-center justify-between p-2 rounded-xl bg-white border border-slate-200 text-xs text-slate-700 hover:border-slate-300 transition-colors"
                              >
                                <div className="flex-1 min-w-0 pr-2">
                                  <div className="flex items-center gap-1 text-[11px] font-medium text-slate-800 truncate">
                                    <span className="truncate max-w-[70px]" title={fromNode?.text}>
                                      {fromNode?.text || 'Nodo'}
                                    </span>
                                    <ArrowRight className="w-3 h-3 text-cyan-500 shrink-0" />
                                    <span className="truncate max-w-[70px]" title={toNode?.text}>
                                      {toNode?.text || 'Nodo'}
                                    </span>
                                  </div>
                                  {conn.label && (
                                    <div className="text-[10px] text-slate-400 truncate italic">
                                      "{conn.label}"
                                    </div>
                                  )}
                                </div>

                                <div className="flex items-center gap-1.5 shrink-0">
                                  <div
                                    style={{ backgroundColor: conn.color || '#3b82f6' }}
                                    className="w-3.5 h-3.5 rounded-full border border-slate-200"
                                  />
                                  {onDeleteConnector && (
                                    <button
                                      type="button"
                                      onClick={() => onDeleteConnector(conn.id)}
                                      title="Eliminar conector"
                                      className="p-1 text-slate-400 hover:text-red-600 rounded hover:bg-red-50 transition-colors cursor-pointer"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      ) : (
                        <div className="p-3 bg-white rounded-xl border border-dashed border-slate-200 text-center text-slate-400">
                          <p className="text-[11px]">No hay conectores flotantes.</p>
                          <p className="text-[10px] text-slate-400 mt-0.5">
                            Relaciona ideas entre diferentes ramas haciendo clic en "+ Nuevo".
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* 4. SEPARACIÓN DE NODOS (HORIZONTAL Y VERTICAL) */}
                <div className="bg-slate-50/80 border border-slate-200/90 rounded-2xl shadow-2xs overflow-hidden transition-all">
                  {/* Collapsible Header */}
                  <button
                    type="button"
                    onClick={() => toggleMapSection('gaps')}
                    className="w-full px-3.5 py-3 flex items-center justify-between text-left hover:bg-slate-100/70 transition-colors cursor-pointer select-none"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-6 h-6 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
                        <Sliders className="w-3.5 h-3.5" />
                      </div>
                      <div className="min-w-0">
                        <label className="font-semibold text-slate-800 text-xs block truncate cursor-pointer">
                          Separación de Nodos
                        </label>
                        <span className="text-[10px] text-slate-400 font-normal block truncate">
                          H: {currentHGap}px · V: {currentVGap}px
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {(currentHGap !== 54 || currentVGap !== 14) && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onUpdateMapGaps?.({ horizontal: 54, vertical: 14 });
                          }}
                          className="flex items-center gap-1 text-[10px] text-slate-500 hover:text-indigo-600 font-medium px-2 py-0.5 rounded-lg hover:bg-indigo-50 transition-colors"
                          title="Restablecer espaciados por defecto (54px / 14px)"
                        >
                          <RotateCcw className="w-3 h-3" /> Restablecer
                        </button>
                      )}
                      <ChevronDown
                        className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${
                          mapSectionsOpen.gaps ? 'rotate-0' : '-rotate-90'
                        }`}
                      />
                    </div>
                  </button>

                  {/* Collapsible Body */}
                  {mapSectionsOpen.gaps && (
                    <div className="px-3.5 pb-3.5 pt-1 space-y-3.5 border-t border-slate-200/60 animate-in fade-in duration-150">
                      {/* Horizontal Separation Slider & Number Input */}
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <MoveHorizontal className="w-3.5 h-3.5 text-blue-600" />
                            <span className="text-[11px] font-semibold text-slate-700">Separación Horizontal</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              min="15"
                              max="250"
                              value={currentHGap}
                              onChange={(e) => {
                                const val = Math.max(10, Math.min(300, Number(e.target.value) || 20));
                                onUpdateMapGaps?.({ horizontal: val });
                              }}
                              className="w-14 px-1.5 py-0.5 bg-white border border-slate-200 rounded-md text-xs text-right font-medium text-slate-700 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                            />
                            <span className="text-[10px] text-slate-400 font-medium">px</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <input
                            type="range"
                            min="20"
                            max="180"
                            step="2"
                            value={currentHGap}
                            onChange={(e) => onUpdateMapGaps?.({ horizontal: Number(e.target.value) })}
                            className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600 focus:outline-none"
                          />
                        </div>

                        <div className="flex items-center justify-between gap-1 pt-0.5">
                          {[
                            { label: 'Compacto', val: 36 },
                            { label: 'Normal', val: 60 },
                            { label: 'Amplio', val: 96 },
                            { label: 'Extenso', val: 140 },
                          ].map((preset) => (
                            <button
                              key={preset.label}
                              type="button"
                              onClick={() => onUpdateMapGaps?.({ horizontal: preset.val })}
                              className={`text-[9.5px] px-1.5 py-0.5 rounded-md transition-colors cursor-pointer ${
                                currentHGap === preset.val
                                  ? 'bg-blue-100 text-blue-700 font-bold border border-blue-200'
                                  : 'bg-white border border-slate-200 text-slate-500 hover:bg-slate-50'
                              }`}
                            >
                              {preset.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Vertical Separation Slider & Number Input */}
                      <div className="space-y-1.5 pt-2 border-t border-slate-200/70">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <MoveVertical className="w-3.5 h-3.5 text-indigo-600" />
                            <span className="text-[11px] font-semibold text-slate-700">Separación Vertical</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              min="4"
                              max="180"
                              value={currentVGap}
                              onChange={(e) => {
                                const val = Math.max(4, Math.min(200, Number(e.target.value) || 6));
                                onUpdateMapGaps?.({ vertical: val });
                              }}
                              className="w-14 px-1.5 py-0.5 bg-white border border-slate-200 rounded-md text-xs text-right font-medium text-slate-700 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                            />
                            <span className="text-[10px] text-slate-400 font-medium">px</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <input
                            type="range"
                            min="6"
                            max="100"
                            step="2"
                            value={currentVGap}
                            onChange={(e) => onUpdateMapGaps?.({ vertical: Number(e.target.value) })}
                            className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600 focus:outline-none"
                          />
                        </div>

                        <div className="flex items-center justify-between gap-1 pt-0.5">
                          {[
                            { label: 'Compacto', val: 12 },
                            { label: 'Normal', val: 24 },
                            { label: 'Amplio', val: 44 },
                            { label: 'Extenso', val: 72 },
                          ].map((preset) => (
                            <button
                              key={preset.label}
                              type="button"
                              onClick={() => onUpdateMapGaps?.({ vertical: preset.val })}
                              className={`text-[9.5px] px-1.5 py-0.5 rounded-md transition-colors cursor-pointer ${
                                currentVGap === preset.val
                                  ? 'bg-indigo-100 text-indigo-700 font-bold border border-indigo-200'
                                  : 'bg-white border border-slate-200 text-slate-500 hover:bg-slate-50'
                              }`}
                            >
                              {preset.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* 5. TIPO DE DISTRIBUCIÓN DE LOS NODOS */}
                <div className="bg-slate-50/80 border border-slate-200/90 rounded-2xl shadow-2xs overflow-hidden transition-all">
                  {/* Collapsible Header */}
                  <button
                    type="button"
                    onClick={() => toggleMapSection('layout')}
                    className="w-full px-3.5 py-3 flex items-center justify-between text-left hover:bg-slate-100/70 transition-colors cursor-pointer select-none"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-6 h-6 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
                        <LayoutGrid className="w-3.5 h-3.5" />
                      </div>
                      <div className="min-w-0">
                        <label className="font-semibold text-slate-800 text-xs block truncate cursor-pointer">
                          Distribución de Nodos
                        </label>
                        <span className="text-[10px] text-slate-400 font-normal block truncate">
                          8 algoritmos de auto-distribución
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-blue-100 text-blue-700">
                        8 Modos
                      </span>
                      <ChevronDown
                        className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${
                          mapSectionsOpen.layout ? 'rotate-0' : '-rotate-90'
                        }`}
                      />
                    </div>
                  </button>

                  {/* Collapsible Body */}
                  {mapSectionsOpen.layout && (
                    <div className="px-3.5 pb-3.5 pt-1 space-y-2 border-t border-slate-200/60 animate-in fade-in duration-150">
                      <div className="grid grid-cols-1 gap-2">
                        {[
                          {
                            id: 'standard',
                            title: 'Equilibrado vertical (el actual)',
                            tag: 'Clásico Doble Lado',
                            desc: 'Ramas divididas a izquierda y derecha, apiladas verticalmente',
                            renderIcon: (active: boolean) => (
                              <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <rect x="9" y="8" width="6" height="8" rx="1.5" className={active ? 'fill-blue-500 stroke-blue-600' : 'fill-slate-300 stroke-slate-400'} />
                                <path d="M9 12H3m0 0v-3m0 3v3" className={active ? 'stroke-blue-500' : 'stroke-slate-400'} />
                                <path d="M15 12h6m0 0v-3m0 3v3" className={active ? 'stroke-blue-500' : 'stroke-slate-400'} />
                              </svg>
                            ),
                          },
                          {
                            id: 'balanced-horizontal',
                            title: 'Equilibrado horizontal',
                            tag: 'Arriba y Abajo',
                            desc: 'Ramas divididas arriba y abajo, distribuidas horizontalmente',
                            renderIcon: (active: boolean) => (
                              <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <rect x="8" y="9" width="8" height="6" rx="1.5" className={active ? 'fill-blue-500 stroke-blue-600' : 'fill-slate-300 stroke-slate-400'} />
                                <path d="M12 9V3m0 0H9m3 0h3" className={active ? 'stroke-blue-500' : 'stroke-slate-400'} />
                                <path d="M12 15v6m0 0H9m3 0h3" className={active ? 'stroke-blue-500' : 'stroke-slate-400'} />
                              </svg>
                            ),
                          },
                          {
                            id: 'left',
                            title: 'Hacia la izquierda',
                            tag: 'Solo Izquierda',
                            desc: 'Árbol unilateral con todas las ramas extendiéndose hacia la izquierda',
                            renderIcon: (active: boolean) => (
                              <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <rect x="15" y="8" width="6" height="8" rx="1.5" className={active ? 'fill-blue-500 stroke-blue-600' : 'fill-slate-300 stroke-slate-400'} />
                                <path d="M15 12H9m0 0v-5h-5m5 5v5h-5" className={active ? 'stroke-blue-500' : 'stroke-slate-400'} />
                              </svg>
                            ),
                          },
                          {
                            id: 'right',
                            title: 'Hacia la derecha',
                            tag: 'Solo Derecha',
                            desc: 'Árbol unilateral con todas las ramas extendiéndose hacia la derecha',
                            renderIcon: (active: boolean) => (
                              <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <rect x="3" y="8" width="6" height="8" rx="1.5" className={active ? 'fill-blue-500 stroke-blue-600' : 'fill-slate-300 stroke-slate-400'} />
                                <path d="M9 12h6m0 0v-5h5m-5 5v5h5" className={active ? 'stroke-blue-500' : 'stroke-slate-400'} />
                              </svg>
                            ),
                          },
                          {
                            id: 'top',
                            title: 'Hacia arriba',
                            tag: 'Jerarquía Ascendente',
                            desc: 'Nodo raíz en la base y ramas creciendo verticalmente hacia arriba',
                            renderIcon: (active: boolean) => (
                              <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <rect x="8" y="15" width="8" height="6" rx="1.5" className={active ? 'fill-blue-500 stroke-blue-600' : 'fill-slate-300 stroke-slate-400'} />
                                <path d="M12 15V9m0 0H6V4m6 5h6V4" className={active ? 'stroke-blue-500' : 'stroke-slate-400'} />
                              </svg>
                            ),
                          },
                          {
                            id: 'bottom',
                            title: 'Hacia abajo',
                            tag: 'Organigrama Descendente',
                            desc: 'Nodo raíz arriba y ramas creciendo verticalmente hacia abajo (Top-Down)',
                            renderIcon: (active: boolean) => (
                              <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <rect x="8" y="3" width="8" height="6" rx="1.5" className={active ? 'fill-blue-500 stroke-blue-600' : 'fill-slate-300 stroke-slate-400'} />
                                <path d="M12 9v6m0 0H6v5m6-5h6v5" className={active ? 'stroke-blue-500' : 'stroke-slate-400'} />
                              </svg>
                            ),
                          },
                          {
                            id: 'radial',
                            title: 'Radial (Por padre local)',
                            tag: 'Agrupación Local',
                            desc: 'Los nodos hijos se agrupan alrededor de su propio padre sin depender de la raíz',
                            renderIcon: (active: boolean) => (
                              <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <circle cx="12" cy="12" r="3.5" className={active ? 'fill-blue-500 stroke-blue-600' : 'fill-slate-300 stroke-slate-400'} />
                                <circle cx="5" cy="7" r="2" className={active ? 'fill-indigo-400 stroke-indigo-500' : 'fill-slate-300 stroke-slate-400'} />
                                <circle cx="19" cy="7" r="2" className={active ? 'fill-indigo-400 stroke-indigo-500' : 'fill-slate-300 stroke-slate-400'} />
                                <circle cx="12" cy="20" r="2" className={active ? 'fill-indigo-400 stroke-indigo-500' : 'fill-slate-300 stroke-slate-400'} />
                                <path d="M7 8.5L9.5 10.5M17 8.5L14.5 10.5M12 15.5V18" className={active ? 'stroke-blue-400' : 'stroke-slate-300'} />
                              </svg>
                            ),
                          },
                          {
                            id: 'circular',
                            title: 'Circular concéntrico',
                            tag: 'Por Capas',
                            desc: 'Círculo concéntrico a la raíz; los nietos completan el arco asignado a su padre',
                            renderIcon: (active: boolean) => (
                              <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                                <circle cx="12" cy="12" r="2.5" className={active ? 'fill-blue-500 stroke-blue-600' : 'fill-slate-300 stroke-slate-400'} />
                                <circle cx="12" cy="12" r="6.5" className={active ? 'stroke-blue-400 stroke-dasharray-[2_2]' : 'stroke-slate-300 stroke-dasharray-[2_2]'} />
                                <circle cx="12" cy="12" r="10" className={active ? 'stroke-indigo-400 stroke-dasharray-[2_2]' : 'stroke-slate-200 stroke-dasharray-[2_2]'} />
                                <circle cx="12" cy="5.5" r="1.5" className={active ? 'fill-blue-600 stroke-blue-700' : 'fill-slate-400'} />
                                <circle cx="17.5" cy="15.5" r="1.5" className={active ? 'fill-blue-600 stroke-blue-700' : 'fill-slate-400'} />
                                <circle cx="6.5" cy="15.5" r="1.5" className={active ? 'fill-blue-600 stroke-blue-700' : 'fill-slate-400'} />
                              </svg>
                            ),
                          },
                        ].map((item) => {
                          const isSelected =
                            layout === item.id || (item.id === 'bottom' && layout === 'tree-down');
                          return (
                            <button
                              key={item.id}
                              onClick={() => onUpdateMapLayout(item.id as LayoutType)}
                              className={`w-full text-left p-2.5 rounded-xl border transition-all flex items-start gap-2.5 group cursor-pointer ${
                                isSelected
                                  ? 'bg-blue-50/80 border-blue-500 ring-2 ring-blue-500/20 shadow-2xs'
                                  : 'bg-white border-slate-200 hover:bg-slate-50 hover:border-slate-300'
                              }`}
                            >
                              <div
                                className={`p-1.5 rounded-lg border shrink-0 transition-colors ${
                                  isSelected
                                    ? 'bg-blue-100/70 border-blue-300 text-blue-600'
                                    : 'bg-slate-50 border-slate-200 text-slate-500 group-hover:text-slate-700 group-hover:bg-slate-100'
                                }`}
                              >
                                {item.renderIcon(isSelected)}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between gap-1 mb-0.5">
                                  <span
                                    className={`text-xs font-semibold truncate ${
                                      isSelected ? 'text-blue-900' : 'text-slate-800'
                                    }`}
                                  >
                                    {item.title}
                                  </span>
                                  <span
                                    className={`text-[9px] font-medium px-1.5 py-0.2 rounded-md shrink-0 ${
                                      isSelected
                                        ? 'bg-blue-200/80 text-blue-800 font-semibold'
                                        : 'bg-slate-100 text-slate-500'
                                    }`}
                                  >
                                    {item.tag}
                                  </span>
                                </div>
                                <p className="text-[10px] text-slate-500 leading-tight">
                                  {item.desc}
                                </p>
                              </div>
                              {isSelected && (
                                <div className="w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0 self-center">
                                  <Check className="w-2.5 h-2.5" />
                                </div>
                              )}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>

                {/* 6. TEMA VISUAL */}
                <div className="bg-slate-50/80 border border-slate-200/90 rounded-2xl shadow-2xs overflow-hidden transition-all">
                  {/* Collapsible Header */}
                  <button
                    type="button"
                    onClick={() => toggleMapSection('theme')}
                    className="w-full px-3.5 py-3 flex items-center justify-between text-left hover:bg-slate-100/70 transition-colors cursor-pointer select-none"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-6 h-6 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center shrink-0">
                        <Palette className="w-3.5 h-3.5" />
                      </div>
                      <div className="min-w-0">
                        <label className="font-semibold text-slate-800 text-xs block truncate cursor-pointer">
                          Tema Visual del Mapa
                        </label>
                        <span className="text-[10px] text-slate-400 font-normal block truncate">
                          {currentTheme.name}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <div className="flex gap-1">
                        {currentTheme.branchColors.slice(0, 3).map((bc, i) => (
                          <div key={i} style={{ backgroundColor: bc }} className="w-2 h-2 rounded-full" />
                        ))}
                      </div>
                      <ChevronDown
                        className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${
                          mapSectionsOpen.theme ? 'rotate-0' : '-rotate-90'
                        }`}
                      />
                    </div>
                  </button>

                  {/* Collapsible Body */}
                  {mapSectionsOpen.theme && (
                    <div className="px-3.5 pb-3.5 pt-1 space-y-2 border-t border-slate-200/60 animate-in fade-in duration-150">
                      {Object.values(THEMES).map((thm) => (
                        <button
                          key={thm.id}
                          onClick={() => onUpdateMapTheme(thm.id)}
                          className={`w-full p-2.5 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                            currentTheme.id === thm.id
                              ? 'border-blue-500 ring-2 ring-blue-500/20 bg-blue-50/50 shadow-2xs'
                              : 'bg-white border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <div
                              style={{ backgroundColor: thm.rootBg }}
                              className="w-4 h-4 rounded-full border border-slate-200"
                            />
                            <span className="font-medium text-slate-800 text-xs">{thm.name}</span>
                          </div>
                          <div className="flex gap-1">
                            {thm.branchColors.slice(0, 4).map((bc, i) => (
                              <div key={i} style={{ backgroundColor: bc }} className="w-2.5 h-2.5 rounded-full" />
                            ))}
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </aside>
  );
};
