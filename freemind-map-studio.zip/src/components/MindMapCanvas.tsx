import React, { useRef, useState, useEffect, useCallback } from 'react';
import {
  MindMap,
  MindNode,
  CalculatedNodeLayout,
  MindMapTheme,
  Connector,
} from '../types/mindmap';
import {
  computeMindMapLayout,
  generateEdgePath,
  generateRibbonEdgePath,
  computeCloudBounds,
} from '../utils/layoutEngine';
import { NodeComponent } from './NodeComponent';
import { MiniMap } from './MiniMap';
import {
  ZoomIn,
  ZoomOut,
  Maximize2,
  Compass,
  Plus,
  Trash2,
  Edit2,
  FolderPlus,
  Link,
  Cloud,
  CheckSquare,
  Copy,
  Scissors,
  Clipboard,
} from 'lucide-react';

interface MindMapCanvasProps {
  mindMap: MindMap;
  theme: MindMapTheme;
  selectedNodeId: string | null;
  editingNodeId: string | null;
  searchMatches?: Set<string>;
  onSelectNode: (id: string | null) => void;
  onStartEditing: (id: string) => void;
  onFinishEditing: () => void;
  onUpdateNodeText: (id: string, text: string) => void;
  onAddChildNode: (parentId: string) => void;
  onAddSiblingNode: (siblingId: string) => void;
  onDeleteNode: (id: string) => void;
  onToggleFoldNode: (id: string) => void;
  onReparentNode: (draggedId: string, targetParentId: string) => void;
  onOpenNotePanel: (id: string) => void;
  onOpenConnectorModal: (fromId: string) => void;
  onToggleCloud: (nodeId: string) => void;
  onCopyNode: (id: string) => void;
  onCutNode: (id: string) => void;
  onPasteNode: (targetParentId: string) => void;
}

interface ContextMenuState {
  visible: boolean;
  x: number;
  y: number;
  nodeId: string | null;
}

export const MindMapCanvas: React.FC<MindMapCanvasProps> = ({
  mindMap,
  theme,
  selectedNodeId,
  editingNodeId,
  searchMatches,
  onSelectNode,
  onStartEditing,
  onFinishEditing,
  onUpdateNodeText,
  onAddChildNode,
  onAddSiblingNode,
  onDeleteNode,
  onToggleFoldNode,
  onReparentNode,
  onOpenNotePanel,
  onOpenConnectorModal,
  onToggleCloud,
  onCopyNode,
  onCutNode,
  onPasteNode,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  // Pan & Zoom state
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState<boolean>(false);
  const [panStart, setPanStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Drag & Drop Node state
  const [draggedNodeId, setDraggedNodeId] = useState<string | null>(null);
  const [dragOverNodeId, setDragOverNodeId] = useState<string | null>(null);

  // Context Menu state
  const [contextMenu, setContextMenu] = useState<ContextMenuState>({
    visible: false,
    x: 0,
    y: 0,
    nodeId: null,
  });

  // Mini-map toggle
  const [showMiniMap, setShowMiniMap] = useState<boolean>(true);

  // Container dimensions for responsive minimap calculations
  const [containerSize, setContainerSize] = useState<{ width: number; height: number }>({
    width: 1200,
    height: 800,
  });

  useEffect(() => {
    if (!containerRef.current) return;
    const updateSize = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        setContainerSize({ width: rect.width, height: rect.height });
      }
    };
    updateSize();
    const observer = new ResizeObserver(updateSize);
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  // Center canvas on initial load
  useEffect(() => {
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      setPan({
        x: rect.width / 2,
        y: rect.height / 2,
      });
    }
  }, []);

  // Compute Layout of all nodes
  const layoutMap = React.useMemo(() => {
    return computeMindMapLayout(mindMap, { x: 0, y: 0 });
  }, [mindMap]);

  // Fit View / Center Function
  const handleFitView = useCallback(() => {
    if (!containerRef.current || layoutMap.size === 0) return;

    const rect = containerRef.current.getBoundingClientRect();
    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;

    (Array.from(layoutMap.values()) as CalculatedNodeLayout[]).forEach((l) => {
      minX = Math.min(minX, l.x);
      maxX = Math.max(maxX, l.x + l.width);
      minY = Math.min(minY, l.y);
      maxY = Math.max(maxY, l.y + l.height);
    });

    const mapWidth = maxX - minX + 160;
    const mapHeight = maxY - minY + 160;

    const scaleX = rect.width / mapWidth;
    const scaleY = rect.height / mapHeight;
    const newZoom = Math.min(Math.max(Math.min(scaleX, scaleY), 0.35), 1.25);

    const centerX = (minX + maxX) / 2;
    const centerY = (minY + maxY) / 2;

    setZoom(newZoom);
    setPan({
      x: rect.width / 2 - centerX * newZoom,
      y: rect.height / 2 - centerY * newZoom,
    });
  }, [layoutMap]);

  // Handle Pan Events
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 0 && (e.target === containerRef.current || (e.target as HTMLElement).id === 'svg-edges-layer' || (e.target as HTMLElement).id === 'canvas-background')) {
      setIsPanning(true);
      setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
      onSelectNode(null);
      setContextMenu((prev) => ({ ...prev, visible: false }));
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isPanning) {
      setPan({
        x: e.clientX - panStart.x,
        y: e.clientY - panStart.y,
      });
    }

    if (draggedNodeId) {
      // Find element under cursor
      const el = document.elementFromPoint(e.clientX, e.clientY);
      const nodeEl = el?.closest('[id^="node-"]');
      if (nodeEl) {
        const id = nodeEl.id.replace('node-', '');
        if (id !== draggedNodeId) {
          setDragOverNodeId(id);
          return;
        }
      }
      setDragOverNodeId(null);
    }
  };

  const handleMouseUp = () => {
    setIsPanning(false);

    if (draggedNodeId && dragOverNodeId && draggedNodeId !== dragOverNodeId) {
      onReparentNode(draggedNodeId, dragOverNodeId);
    }
    setDraggedNodeId(null);
    setDragOverNodeId(null);
  };

  // Wheel Zoom
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    if (!containerRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const zoomFactor = e.deltaY < 0 ? 1.12 : 0.89;
    const newZoom = Math.min(Math.max(zoom * zoomFactor, 0.2), 2.5);

    // Zoom towards mouse pointer
    const newPanX = mouseX - (mouseX - pan.x) * (newZoom / zoom);
    const newPanY = mouseY - (mouseY - pan.y) * (newZoom / zoom);

    setZoom(newZoom);
    setPan({ x: newPanX, y: newPanY });
  };

  // Right Click Context Menu
  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    const target = e.target as HTMLElement;
    const nodeEl = target.closest('[id^="node-"]');
    const nodeId = nodeEl ? nodeEl.id.replace('node-', '') : null;

    if (nodeId) {
      onSelectNode(nodeId);
    }

    // Auto-adjust position so menu never gets cut off at bottom or right screen edges
    const estimatedMenuWidth = 240;
    const estimatedMenuHeight = 360;
    const padding = 12;

    let posX = e.clientX;
    let posY = e.clientY;

    if (posX + estimatedMenuWidth > window.innerWidth - padding) {
      posX = Math.max(padding, window.innerWidth - estimatedMenuWidth - padding);
    }

    if (posY + estimatedMenuHeight > window.innerHeight - padding) {
      // Shift upwards above click position or clamp to bottom edge
      posY = Math.max(padding, window.innerHeight - estimatedMenuHeight - padding);
    }

    setContextMenu({
      visible: true,
      x: posX,
      y: posY,
      nodeId,
    });
  };

  // Close context menu on global click
  useEffect(() => {
    const handleGlobalClick = () => {
      if (contextMenu.visible) {
        setContextMenu((prev) => ({ ...prev, visible: false }));
      }
    };
    window.addEventListener('click', handleGlobalClick);
    return () => window.removeEventListener('click', handleGlobalClick);
  }, [contextMenu.visible]);

  // Determine Branch Color for an edge
  const getBranchColor = (childLayout: CalculatedNodeLayout): string => {
    const colors = theme.branchColors;
    return colors[childLayout.branchIndex % colors.length] || '#3b82f6';
  };

  // Background style values (override from mindMap if set, else from theme)
  const effectiveBgColor = mindMap.backgroundColor || theme.background || '#f8fafc';
  const effectivePattern = mindMap.backgroundPattern || theme.backgroundPattern || 'dots';
  const effectivePatternColor = mindMap.backgroundPatternColor || theme.backgroundPatternColor || '#94a3b8';
  const effectivePatternSize = mindMap.backgroundPatternSize || theme.backgroundPatternSize || 24;
  const effectivePatternOpacity = mindMap.backgroundPatternOpacity ?? theme.backgroundPatternOpacity ?? 0.45;

  // Triangular & Hexagonal geometry calculations
  const triangleW = effectivePatternSize;
  const triangleH = Math.round(effectivePatternSize * 1.7320508) || 42;

  const hexW = effectivePatternSize;
  const hexH = Math.round(effectivePatternSize * 1.7320508) || 42;
  const hexW2 = hexW / 2;
  const hexH4 = hexH / 4;
  const hexH2 = hexH / 2;
  const hexH34 = (3 * hexH) / 4;

  return (
    <div
      ref={containerRef}
      id="canvas-background"
      style={{ backgroundColor: effectiveBgColor }}
      className="relative flex-1 w-full h-full overflow-hidden cursor-grab active:cursor-grabbing select-none"
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onWheel={handleWheel}
      onContextMenu={handleContextMenu}
    >
      {/* Viewport Transform Container */}
      <div
        id="canvas-viewport"
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          transformOrigin: '0 0',
        }}
        className="absolute top-0 left-0 w-full h-full pointer-events-none"
      >
        {/* SVG Rendering Layer for Background Patterns, Edges, Clouds and Connectors */}
        <svg
          id="svg-edges-layer"
          className="absolute top-0 left-0 w-full h-full overflow-visible pointer-events-none"
          style={{ overflow: 'visible' }}
        >
          <defs>
            {/* Arrowhead marker for connectors */}
            <marker
              id="connector-arrow"
              viewBox="0 0 10 10"
              refX="8"
              refY="5"
              markerWidth="6"
              markerHeight="6"
              orient="auto-start-reverse"
            >
              <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#3b82f6" />
            </marker>

            {/* Pattern 1: Dots (Puntos) */}
            {effectivePattern === 'dots' && (
              <pattern
                id="canvas-bg-pattern"
                width={effectivePatternSize}
                height={effectivePatternSize}
                patternUnits="userSpaceOnUse"
              >
                <circle
                  cx={effectivePatternSize / 2}
                  cy={effectivePatternSize / 2}
                  r={1.5}
                  fill={effectivePatternColor}
                  fillOpacity={effectivePatternOpacity}
                />
              </pattern>
            )}

            {/* Pattern 2: Lines (Líneas horizontales) */}
            {effectivePattern === 'lines' && (
              <pattern
                id="canvas-bg-pattern"
                width={effectivePatternSize}
                height={effectivePatternSize}
                patternUnits="userSpaceOnUse"
              >
                <line
                  x1="0"
                  y1={effectivePatternSize}
                  x2={effectivePatternSize}
                  y2={effectivePatternSize}
                  stroke={effectivePatternColor}
                  strokeWidth="1"
                  strokeOpacity={effectivePatternOpacity}
                />
              </pattern>
            )}

            {/* Pattern 3: Squares (Cuadrados / Cuadrícula) */}
            {effectivePattern === 'squares' && (
              <pattern
                id="canvas-bg-pattern"
                width={effectivePatternSize}
                height={effectivePatternSize}
                patternUnits="userSpaceOnUse"
              >
                <path
                  d={`M ${effectivePatternSize} 0 L 0 0 0 ${effectivePatternSize}`}
                  fill="none"
                  stroke={effectivePatternColor}
                  strokeWidth="1"
                  strokeOpacity={effectivePatternOpacity}
                />
              </pattern>
            )}

            {/* Pattern 4: Triangles (Triángulos / Malla isométrica) */}
            {effectivePattern === 'triangles' && (
              <pattern
                id="canvas-bg-pattern"
                width={triangleW}
                height={triangleH}
                patternUnits="userSpaceOnUse"
              >
                <path
                  d={`M 0 0 L ${triangleW} 0 L ${triangleW / 2} ${triangleH / 2} Z M 0 ${triangleH} L ${triangleW} ${triangleH} L ${triangleW / 2} ${triangleH / 2} Z M 0 0 L ${triangleW / 2} ${triangleH / 2} L 0 ${triangleH} Z M ${triangleW} 0 L ${triangleW} ${triangleH} L ${triangleW / 2} ${triangleH / 2} Z`}
                  fill="none"
                  stroke={effectivePatternColor}
                  strokeWidth="1"
                  strokeOpacity={effectivePatternOpacity}
                />
              </pattern>
            )}

            {/* Pattern 5: Hexagons (Hexágonos / Panal Honeycomb) */}
            {effectivePattern === 'hexagons' && (
              <pattern
                id="canvas-bg-pattern"
                width={hexW}
                height={hexH}
                patternUnits="userSpaceOnUse"
              >
                <path
                  d={`M ${hexW2} 0 L ${hexW} ${hexH4} L ${hexW} ${hexH34} L ${hexW2} ${hexH} L 0 ${hexH34} L 0 ${hexH4} Z M 0 0 L ${hexW2} ${hexH4} M ${hexW} 0 L ${hexW2} ${hexH4} M 0 ${hexH} L ${hexW2} ${hexH34} M ${hexW} ${hexH} L ${hexW2} ${hexH34}`}
                  fill="none"
                  stroke={effectivePatternColor}
                  strokeWidth="1"
                  strokeOpacity={effectivePatternOpacity}
                />
              </pattern>
            )}
          </defs>

          {/* Group 0: Dynamic Background Pattern Plane */}
          {effectivePattern !== 'none' && (
            <rect
              id="canvas-pattern-plane"
              x="-200000"
              y="-200000"
              width="400000"
              height="400000"
              fill="url(#canvas-bg-pattern)"
            />
          )}

          {/* Group 1: Clouds (rendered behind edges and nodes) */}
          <g id="clouds-group">
            {(Object.values(mindMap.nodes) as MindNode[]).map((node) => {
              if (!node.cloud?.enabled) return null;
              const bounds = computeCloudBounds(node.id, mindMap.nodes, layoutMap);
              if (!bounds) return null;

              return (
                <rect
                  key={`cloud-${node.id}`}
                  x={bounds.x}
                  y={bounds.y}
                  width={bounds.width}
                  height={bounds.height}
                  rx={node.cloud.shape === 'round-rectangle' ? 18 : 26}
                  ry={node.cloud.shape === 'round-rectangle' ? 18 : 26}
                  fill={node.cloud.color || 'rgba(59, 130, 246, 0.08)'}
                  stroke={node.cloud.color?.replace('0.08', '0.4') || '#93c5fd'}
                  strokeWidth="1.5"
                  strokeDasharray="4 3"
                />
              );
            })}
          </g>

          {/* Group 2: Hierarchical Tree Edges */}
          <g id="tree-edges-group">
            {(Array.from(layoutMap.values()) as CalculatedNodeLayout[]).map((childLayout) => {
              const childNode = mindMap.nodes[childLayout.id];
              if (!childNode || !childNode.parentId) return null;

              const parentLayout = layoutMap.get(childNode.parentId);
              if (!parentLayout) return null;

              const effectiveStyle = childNode.edgeStyle || mindMap.edgeStyle || theme.edgeStyle || 'bezier';
              if (effectiveStyle === 'hidden') return null;

              const edgePath = generateEdgePath(
                parentLayout,
                childLayout,
                effectiveStyle,
                childNode.shape
              );

              if (!edgePath) return null;

              const color = childNode.edgeColor || mindMap.edgeColor || getBranchColor(childLayout);
              const defaultWidth = childLayout.depth === 1 ? 2.5 : 1.75;
              const width = childNode.edgeWidth || mindMap.edgeWidth || defaultWidth;
              const effectiveDash = childNode.edgeDash || mindMap.edgeDash || 'solid';
              const effectiveProfile = childNode.edgeProfile || mindMap.edgeProfile || 'uniform';

              // Calculate stroke dash pattern with proper, legible spacing
              const strokeDasharray =
                effectiveDash === 'dashed'
                  ? `${Math.max(10, width * 3.5)} ${Math.max(7, width * 2.5)}`
                  : effectiveDash === 'dotted'
                  ? `0.1 ${Math.max(8, width * 3.0)}`
                  : undefined;

              // If a variable-width profile is active, render dynamic filled ribbon
              if (effectiveProfile !== 'uniform') {
                const ribbonPath = generateRibbonEdgePath(
                  parentLayout,
                  childLayout,
                  effectiveStyle,
                  childNode.shape,
                  effectiveProfile,
                  width
                );
                if (ribbonPath) {
                  // If solid, render opaque filled ribbon
                  if (effectiveDash === 'solid') {
                    return (
                      <path
                        key={`edge-${childNode.parentId}-${childNode.id}`}
                        d={ribbonPath}
                        fill={color}
                        fillOpacity={0.92}
                        stroke={color}
                        strokeWidth={0.5}
                        strokeLinejoin="round"
                      />
                    );
                  }

                  // If dashed or dotted with variable thickness profile, render both profile silhouette and dashed spine
                  return (
                    <g key={`edge-group-${childNode.parentId}-${childNode.id}`}>
                      <path
                        d={ribbonPath}
                        fill={color}
                        fillOpacity={0.18}
                        stroke={color}
                        strokeWidth={0.5}
                        strokeOpacity={0.4}
                        strokeLinejoin="round"
                      />
                      <path
                        d={edgePath}
                        stroke={color}
                        strokeWidth={width}
                        strokeDasharray={strokeDasharray}
                        fill="none"
                        strokeLinecap="round"
                      />
                    </g>
                  );
                }
              }

              return (
                <path
                  key={`edge-${childNode.parentId}-${childNode.id}`}
                  d={edgePath}
                  stroke={color}
                  strokeWidth={width}
                  strokeDasharray={strokeDasharray}
                  fill="none"
                  strokeLinecap="round"
                />
              );
            })}
          </g>

          {/* Group 3: Custom Connectors / Relations */}
          <g id="connectors-group">
            {mindMap.connectors?.map((conn) => {
              const fromLayout = layoutMap.get(conn.fromId);
              const toLayout = layoutMap.get(conn.toId);
              if (!fromLayout || !toLayout) return null;

              const x1 = fromLayout.x + fromLayout.width / 2;
              const y1 = fromLayout.y + fromLayout.height / 2;
              const x2 = toLayout.x + toLayout.width / 2;
              const y2 = toLayout.y + toLayout.height / 2;

              const midX = (x1 + x2) / 2;
              const midY = (y1 + y2) / 2 - 40; // Curve arc
              const pathD = `M ${x1} ${y1} Q ${midX} ${midY} ${x2} ${y2}`;

              const connectorDash =
                conn.style === 'dashed'
                  ? '10 7'
                  : conn.style === 'dotted'
                  ? '0.1 9'
                  : undefined;

              return (
                <g key={conn.id} className="cursor-pointer pointer-events-auto group">
                  <path
                    d={pathD}
                    stroke={conn.color || '#3b82f6'}
                    strokeWidth="2"
                    strokeDasharray={connectorDash}
                    strokeLinecap="round"
                    fill="none"
                    markerEnd="url(#connector-arrow)"
                  />
                  {conn.label && (
                    <text
                      x={midX}
                      y={midY + 5}
                      textAnchor="middle"
                      className="text-xs font-semibold fill-slate-700 bg-white"
                      style={{ fontSize: '11px', paintOrder: 'stroke', stroke: '#ffffff', strokeWidth: '4px' }}
                    >
                      {conn.label}
                    </text>
                  )}
                </g>
              );
            })}
          </g>
        </svg>

        {/* Nodes Layer (DOM elements for crisp typography and events) */}
        <div id="nodes-layer" className="absolute top-0 left-0 pointer-events-auto">
          {(Array.from(layoutMap.values()) as CalculatedNodeLayout[]).map((layout) => {
            const node = mindMap.nodes[layout.id];
            if (!node) return null;

            const isSelected = selectedNodeId === node.id;
            const isEditing = editingNodeId === node.id;
            const isMatch = searchMatches ? searchMatches.has(node.id) : false;
            const branchColor = getBranchColor(layout);

            return (
              <NodeComponent
                key={node.id}
                node={node}
                layout={layout}
                isSelected={isSelected}
                isEditing={isEditing}
                theme={theme}
                branchColor={branchColor}
                isMatch={isMatch}
                onSelect={(id) => onSelectNode(id)}
                onDoubleClick={(id) => onStartEditing(id)}
                onTextChange={onUpdateNodeText}
                onFinishEditing={onFinishEditing}
                onToggleFold={onToggleFoldNode}
                onAddChild={onAddChildNode}
                onOpenNote={onOpenNotePanel}
                onDragStart={(id) => setDraggedNodeId(id)}
                onDropOnNode={onReparentNode}
              />
            );
          })}
        </div>
      </div>

      {/* Interactive Mini-Map & Zoom Controls */}
      <MiniMap
        mindMap={mindMap}
        layoutMap={layoutMap}
        theme={theme}
        pan={pan}
        zoom={zoom}
        containerWidth={containerSize.width}
        containerHeight={containerSize.height}
        selectedNodeId={selectedNodeId}
        showMiniMap={showMiniMap}
        onPanChange={setPan}
        onSelectNode={onSelectNode}
        onZoomIn={() => setZoom((z) => Math.min(2.5, z * 1.15))}
        onZoomOut={() => setZoom((z) => Math.max(0.2, z / 1.15))}
        onResetZoom={() => setZoom(1)}
        onFitView={handleFitView}
        onToggleMiniMap={() => setShowMiniMap((s) => !s)}
      />

      {/* Right Click Context Menu (Freeplane inspired) */}
      {contextMenu.visible && (
        <div
          style={{ top: `${contextMenu.y}px`, left: `${contextMenu.x}px` }}
          className="fixed z-50 bg-white/98 backdrop-blur-md rounded-xl border border-slate-200/90 shadow-2xl py-1.5 min-w-56 max-h-[calc(100vh-24px)] overflow-y-auto text-xs text-slate-700 font-medium animate-in fade-in zoom-in-95 duration-100"
          onClick={(e) => e.stopPropagation()}
        >
          {contextMenu.nodeId ? (
            <>
              <button
                onClick={() => {
                  onAddChildNode(contextMenu.nodeId!);
                  setContextMenu((prev) => ({ ...prev, visible: false }));
                }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600 transition-colors"
              >
                <span className="flex items-center gap-2">
                  <Plus className="w-3.5 h-3.5 text-blue-600" /> Agregar Nodo Hijo
                </span>
                <kbd className="text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded font-mono">
                  Tab
                </kbd>
              </button>

              <button
                onClick={() => {
                  onAddSiblingNode(contextMenu.nodeId!);
                  setContextMenu((prev) => ({ ...prev, visible: false }));
                }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600 transition-colors"
              >
                <span className="flex items-center gap-2">
                  <FolderPlus className="w-3.5 h-3.5 text-emerald-600" /> Agregar Nodo Hermano
                </span>
                <kbd className="text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded font-mono">
                  Enter
                </kbd>
              </button>

              <button
                onClick={() => {
                  onStartEditing(contextMenu.nodeId!);
                  setContextMenu((prev) => ({ ...prev, visible: false }));
                }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600 transition-colors"
              >
                <span className="flex items-center gap-2">
                  <Edit2 className="w-3.5 h-3.5 text-indigo-600" /> Editar Texto
                </span>
                <kbd className="text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded font-mono">
                  F2
                </kbd>
              </button>

              <div className="my-1 border-t border-slate-100" />

              <button
                onClick={() => {
                  onCopyNode(contextMenu.nodeId!);
                  setContextMenu((prev) => ({ ...prev, visible: false }));
                }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600 transition-colors"
              >
                <span className="flex items-center gap-2">
                  <Copy className="w-3.5 h-3.5 text-slate-500" /> Copiar Rama
                </span>
                <kbd className="text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded font-mono">
                  Ctrl+C
                </kbd>
              </button>

              <button
                onClick={() => {
                  onCutNode(contextMenu.nodeId!);
                  setContextMenu((prev) => ({ ...prev, visible: false }));
                }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600 transition-colors"
              >
                <span className="flex items-center gap-2">
                  <Scissors className="w-3.5 h-3.5 text-slate-500" /> Cortar Rama
                </span>
                <kbd className="text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded font-mono">
                  Ctrl+X
                </kbd>
              </button>

              <button
                onClick={() => {
                  onPasteNode(contextMenu.nodeId!);
                  setContextMenu((prev) => ({ ...prev, visible: false }));
                }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600 transition-colors"
              >
                <span className="flex items-center gap-2">
                  <Clipboard className="w-3.5 h-3.5 text-slate-500" /> Pegar como Hijo
                </span>
                <kbd className="text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded font-mono">
                  Ctrl+V
                </kbd>
              </button>

              <div className="my-1 border-t border-slate-100" />

              <button
                onClick={() => {
                  onOpenConnectorModal(contextMenu.nodeId!);
                  setContextMenu((prev) => ({ ...prev, visible: false }));
                }}
                className="w-full px-3 py-1.5 text-left flex items-center gap-2 hover:bg-blue-50 hover:text-blue-600 transition-colors"
              >
                <Link className="w-3.5 h-3.5 text-cyan-600" /> Crear Conector a otro nodo
              </button>

              <button
                onClick={() => {
                  onToggleCloud(contextMenu.nodeId!);
                  setContextMenu((prev) => ({ ...prev, visible: false }));
                }}
                className="w-full px-3 py-1.5 text-left flex items-center gap-2 hover:bg-blue-50 hover:text-blue-600 transition-colors"
              >
                <Cloud className="w-3.5 h-3.5 text-amber-500" /> Alternar Nube de Rama
              </button>

              {contextMenu.nodeId !== mindMap.rootId && (
                <>
                  <div className="my-1 border-t border-slate-100" />
                  <button
                    onClick={() => {
                      onDeleteNode(contextMenu.nodeId!);
                      setContextMenu((prev) => ({ ...prev, visible: false }));
                    }}
                    className="w-full px-3 py-1.5 text-left flex items-center justify-between text-red-600 hover:bg-red-50 transition-colors"
                  >
                    <span className="flex items-center gap-2">
                      <Trash2 className="w-3.5 h-3.5" /> Eliminar Nodo
                    </span>
                    <kbd className="text-[10px] bg-red-100 text-red-700 px-1.5 py-0.5 rounded font-mono">
                      Supr
                    </kbd>
                  </button>
                </>
              )}
            </>
          ) : (
            <button
              onClick={() => {
                onAddChildNode(mindMap.rootId);
                setContextMenu((prev) => ({ ...prev, visible: false }));
              }}
              className="w-full px-3 py-1.5 text-left flex items-center gap-2 hover:bg-blue-50 hover:text-blue-600 transition-colors"
            >
              <Plus className="w-3.5 h-3.5 text-blue-600" /> Agregar Rama Principal
            </button>
          )}
        </div>
      )}
    </div>
  );
};
