import React, { useState, useRef, useEffect } from 'react';
import { MindNode, CalculatedNodeLayout, MindMapTheme } from '../types/mindmap';
import { renderNodeIcon } from '../utils/iconMap';
import {
  FileText,
  ExternalLink,
  Plus,
  GripVertical,
  ChevronRight,
  ChevronLeft,
  Minus,
} from 'lucide-react';

interface NodeComponentProps {
  node: MindNode;
  layout: CalculatedNodeLayout;
  isSelected: boolean;
  isEditing: boolean;
  theme: MindMapTheme;
  branchColor: string;
  isMatch?: boolean;
  onSelect: (id: string, e: React.MouseEvent) => void;
  onDoubleClick: (id: string) => void;
  onTextChange: (id: string, newText: string) => void;
  onFinishEditing: () => void;
  onToggleFold: (id: string, e: React.MouseEvent) => void;
  onAddChild: (parentId: string) => void;
  onOpenNote: (id: string) => void;
  onDragStart: (id: string, e: React.MouseEvent) => void;
  onDropOnNode: (draggedId: string, targetId: string) => void;
}

export const NodeComponent: React.FC<NodeComponentProps> = ({
  node,
  layout,
  isSelected,
  isEditing,
  theme,
  branchColor,
  isMatch,
  onSelect,
  onDoubleClick,
  onTextChange,
  onFinishEditing,
  onToggleFold,
  onAddChild,
  onOpenNote,
  onDragStart,
  onDropOnNode,
}) => {
  const [editText, setEditText] = useState(node.text);
  const [isHovered, setIsHovered] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const isRoot = !node.parentId;
  const shape = node.shape || (isRoot ? 'bubble' : 'bubble');
  const hasChildren = node.children && node.children.length > 0;

  useEffect(() => {
    setEditText(node.text);
  }, [node.text]);

  useEffect(() => {
    if (isEditing && textareaRef.current) {
      textareaRef.current.focus();
      textareaRef.current.select();
    }
  }, [isEditing]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onTextChange(node.id, editText);
      onFinishEditing();
    } else if (e.key === 'Escape') {
      setEditText(node.text);
      onFinishEditing();
    }
  };

  const handleBlur = () => {
    onTextChange(node.id, editText);
    onFinishEditing();
  };

  // Determine Colors
  const bgColor = isRoot
    ? (node.color || theme.rootBg)
    : (node.color || theme.nodeBg);

  const textColor = isRoot
    ? (node.textColor || theme.rootText)
    : (node.textColor || theme.nodeText);

  const borderColor = node.borderColor || (isRoot ? 'transparent' : branchColor || theme.nodeBorder);
  const borderWidth = node.borderWidth !== undefined ? node.borderWidth : (isRoot ? 0 : 1.5);

  // Shape class generator
  const getShapeStyle = () => {
    if (shape === 'fork') {
      return {
        background: 'transparent',
        borderBottom: `2.5px solid ${branchColor || '#3b82f6'}`,
        borderRadius: 0,
      };
    }
    if (shape === 'pill') {
      return {
        backgroundColor: bgColor,
        border: `${borderWidth}px solid ${borderColor}`,
        borderRadius: '9999px',
        paddingLeft: '14px',
        paddingRight: '14px',
      };
    }
    if (shape === 'oval') {
      return {
        backgroundColor: bgColor,
        border: `${borderWidth}px solid ${borderColor}`,
        borderRadius: '24px',
        paddingLeft: '16px',
        paddingRight: '16px',
      };
    }
    if (shape === 'rectangle') {
      return {
        backgroundColor: bgColor,
        border: `${borderWidth}px solid ${borderColor}`,
        borderRadius: '4px',
      };
    }
    if (shape === 'hexagon') {
      return {
        backgroundColor: bgColor,
        border: `${borderWidth}px solid ${borderColor}`,
        borderRadius: '12px',
        clipPath: 'polygon(8% 0%, 92% 0%, 100% 50%, 92% 100%, 8% 100%, 0% 50%)',
        paddingLeft: '18px',
        paddingRight: '18px',
      };
    }
    // Default Bubble
    return {
      backgroundColor: bgColor,
      border: `${borderWidth}px solid ${borderColor}`,
      borderRadius: isRoot ? '16px' : '10px',
    };
  };

  return (
    <div
      id={`node-${node.id}`}
      style={{
        left: `${layout.x}px`,
        top: `${layout.y}px`,
        width: `${layout.width}px`,
        minHeight: `${layout.height}px`,
        ...getShapeStyle(),
      }}
      className={`absolute select-none flex flex-col justify-center px-3 py-1.5 shadow-xs transition-shadow duration-150 group cursor-pointer ${
        isSelected ? 'ring-3 ring-blue-500 ring-offset-2 ring-offset-slate-50 shadow-md z-30' : 'hover:shadow-md z-10'
      } ${isMatch ? 'ring-2 ring-amber-400 bg-amber-50/90' : ''}`}
      onClick={(e) => onSelect(node.id, e)}
      onDoubleClick={(e) => {
        e.stopPropagation();
        onDoubleClick(node.id);
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Node Content Container */}
      <div className="flex items-center gap-1.5 w-full">
        {/* Drag handle on hover (non-root) */}
        {!isRoot && isHovered && (
          <div
            title="Arrastrar para mover o reordenar rama"
            className="cursor-grab active:cursor-grabbing text-slate-400 hover:text-slate-700 -ml-1.5"
            onMouseDown={(e) => {
              e.stopPropagation();
              onDragStart(node.id, e);
            }}
          >
            <GripVertical className="w-3.5 h-3.5" />
          </div>
        )}

        {/* Node Icons */}
        {node.icons && node.icons.length > 0 && (
          <div className="flex items-center gap-1 shrink-0">
            {node.icons.map((ic, idx) => (
              <span key={idx} className="inline-flex items-center">
                {renderNodeIcon(ic)}
              </span>
            ))}
          </div>
        )}

        {/* Progress indicator */}
        {node.progress !== undefined && (
          <div
            title={`Progreso: ${node.progress}%`}
            className="shrink-0 flex items-center justify-center w-4 h-4 rounded-full border border-slate-300 bg-slate-100 text-[9px] font-bold text-slate-700"
          >
            {node.progress === 100 ? '✓' : `${node.progress}%`}
          </div>
        )}

        {/* Main Text Content (Title & Body) */}
        <div className="flex-1 min-w-0 flex flex-col justify-center">
          {isEditing ? (
            <textarea
              ref={textareaRef}
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              onKeyDown={handleKeyDown}
              onBlur={handleBlur}
              rows={Math.max(1, editText.split('\n').length)}
              className="w-full bg-white text-slate-900 text-sm rounded px-1.5 py-0.5 border border-blue-500 outline-none resize-none overflow-hidden font-medium"
              style={{
                fontSize: `${node.fontSize || (isRoot ? 16 : 14)}px`,
                fontWeight: node.bold ? 700 : 500,
                fontStyle: node.italic ? 'italic' : 'normal',
                textAlign: node.textAlign || 'left',
              }}
            />
          ) : (
            <>
              {/* Title */}
              <div
                className="leading-snug break-words whitespace-pre-wrap select-text"
                style={{
                  color: textColor,
                  fontSize: `${node.fontSize || (isRoot ? 16 : 14)}px`,
                  fontWeight: node.bold ? 700 : (isRoot ? 600 : 500),
                  fontStyle: node.italic ? 'italic' : 'normal',
                  textAlign: node.textAlign || 'left',
                  fontFamily: node.fontFamily,
                }}
              >
                {node.text || 'Nuevo Nodo'}
              </div>

              {/* Body (Cuerpo del nodo) */}
              {node.body && node.body.trim().length > 0 && (
                <div
                  className="mt-1 pt-0.5 leading-relaxed break-words whitespace-pre-wrap select-text border-t border-black/5 dark:border-white/5"
                  style={{
                    color: node.bodyColor || (isRoot ? 'rgba(255,255,255,0.88)' : '#475569'),
                    fontSize: `${node.bodyFontSize || (isRoot ? 13 : 12)}px`,
                    fontWeight: node.bodyBold ? 700 : 400,
                    fontStyle: node.bodyItalic ? 'italic' : 'normal',
                    textAlign: node.bodyAlign || 'left',
                    fontFamily: node.bodyFontFamily,
                  }}
                >
                  {node.body}
                </div>
              )}
            </>
          )}
        </div>

        {/* Note indicator */}
        {node.note && (
          <button
            title="Ver nota detallada (Markdown)"
            onClick={(e) => {
              e.stopPropagation();
              onOpenNote(node.id);
            }}
            className="shrink-0 p-0.5 text-slate-400 hover:text-blue-600 transition-colors"
          >
            <FileText className="w-3.5 h-3.5" />
          </button>
        )}

        {/* Link indicator */}
        {node.link && (
          <a
            href={node.link}
            target="_blank"
            rel="noopener noreferrer"
            title={`Abrir enlace: ${node.link}`}
            onClick={(e) => e.stopPropagation()}
            className="shrink-0 p-0.5 text-slate-400 hover:text-blue-600 transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        )}
      </div>

      {/* Tags in the bottom area of the node */}
      {node.tags && node.tags.length > 0 && (
        <div className="flex flex-wrap items-center gap-1 mt-1 pt-1 border-t border-black/10 dark:border-white/10 w-full shrink-0">
          {node.tags.map((tg, idx) => (
            <span
              key={idx}
              className="text-[10px] leading-tight px-1.5 py-0.5 rounded-md bg-slate-200/80 text-slate-700 font-medium tracking-tight"
            >
              #{tg}
            </span>
          ))}
        </div>
      )}

      {/* Folding / Unfolding Toggle Badge */}
      {hasChildren && (
        <button
          title={
            node.folded
              ? `Desplegar ${node.children.length} sub-nodos (Espacio)`
              : 'Plegar rama (Espacio)'
          }
          onClick={(e) => onToggleFold(node.id, e)}
          style={{
            borderColor: node.folded ? '#f59e0b' : branchColor || '#94a3b8',
          }}
          className={`absolute flex items-center justify-center rounded-full transition-all z-20 shadow-xs cursor-pointer ${
            node.folded
              ? 'min-w-5 h-5 px-1 bg-amber-50 text-amber-800 border-2 border-amber-500 font-bold hover:bg-amber-100 hover:scale-105'
              : 'w-4.5 h-4.5 bg-white text-slate-600 border border-slate-300 hover:bg-indigo-600 hover:text-white hover:border-indigo-600'
          } ${
            layout.side === 'left'
              ? '-left-2.5 top-1/2 -translate-y-1/2'
              : '-right-2.5 top-1/2 -translate-y-1/2'
          }`}
        >
          {node.folded ? (
            <span className="flex items-center gap-0.5 text-[10px] leading-none">
              {layout.side === 'left' ? (
                <ChevronLeft className="w-3 h-3 stroke-[2.5]" />
              ) : (
                <ChevronRight className="w-3 h-3 stroke-[2.5]" />
              )}
              <span className="text-[9px] font-bold font-mono">{node.children.length}</span>
            </span>
          ) : (
            <Minus className="w-2.5 h-2.5 stroke-[2.5]" />
          )}
        </button>
      )}

      {/* Quick Add Child Button on Hover (Placed Higher Up to avoid collision) */}
      {isHovered && !isEditing && (
        <button
          title="Agregar nodo hijo (Tab)"
          onClick={(e) => {
            e.stopPropagation();
            onAddChild(node.id);
          }}
          className={`absolute flex items-center justify-center w-5 h-5 rounded-full bg-blue-600 text-white shadow-md hover:bg-blue-700 hover:scale-110 active:scale-95 transition-all z-20 cursor-pointer ${
            layout.side === 'left' ? '-left-3 -top-2.5' : '-right-3 -top-2.5'
          }`}
        >
          <Plus className="w-3 h-3 stroke-[2.5]" />
        </button>
      )}
    </div>
  );
};
