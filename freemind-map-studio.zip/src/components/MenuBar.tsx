import React, { useState, useRef, useEffect } from 'react';
import { MindMap } from '../types/mindmap';
import {
  FileText,
  Save,
  FolderOpen,
  Plus,
  FileDown,
  FileUp,
  Undo2,
  Redo2,
  Trash2,
  ListTree,
  Presentation,
  HelpCircle,
  Sparkles,
  Maximize,
  LayoutTemplate,
  Cloud,
  Link,
  ChevronDown,
  Check,
} from 'lucide-react';

interface MenuBarProps {
  mindMap: MindMap;
  canUndo: boolean;
  canRedo: boolean;
  isOutlineMode: boolean;
  onNewMap: () => void;
  onOpenTemplates: () => void;
  onOpenSavedMaps: () => void;
  onSaveMap: () => void;
  onOpenExportModal: () => void;
  onOpenImportModal: () => void;
  onUndo: () => void;
  onRedo: () => void;
  onAddChild: () => void;
  onAddSibling: () => void;
  onDeleteNode: () => void;
  onToggleOutline: () => void;
  onStartPresentation: () => void;
  onOpenShortcuts: () => void;
  onToggleFullscreen: () => void;
  onFoldAll: () => void;
  onUnfoldAll: () => void;
  onOpenConnectorModal: () => void;
  onToggleCloud: () => void;
  onTitleChange: (newTitle: string) => void;
  onOpenIconPack?: () => void;
}

export const MenuBar: React.FC<MenuBarProps> = ({
  mindMap,
  canUndo,
  canRedo,
  isOutlineMode,
  onNewMap,
  onOpenTemplates,
  onOpenSavedMaps,
  onSaveMap,
  onOpenExportModal,
  onOpenImportModal,
  onUndo,
  onRedo,
  onAddChild,
  onAddSibling,
  onDeleteNode,
  onToggleOutline,
  onStartPresentation,
  onOpenShortcuts,
  onToggleFullscreen,
  onFoldAll,
  onUnfoldAll,
  onOpenConnectorModal,
  onToggleCloud,
  onTitleChange,
  onOpenIconPack,
}) => {
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [titleInput, setTitleInput] = useState(mindMap.title);

  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setTitleInput(mindMap.title);
  }, [mindMap.title]);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setOpenMenu(null);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleTitleSubmit = () => {
    if (titleInput.trim()) {
      onTitleChange(titleInput.trim());
    }
    setIsEditingTitle(false);
  };

  const handleMenuClick = (menuName: string) => {
    setOpenMenu(openMenu === menuName ? null : menuName);
  };

  return (
    <header
      ref={menuRef}
      className="h-10 bg-slate-900 text-white px-3 flex items-center justify-between z-30 shrink-0 select-none border-b border-slate-800 text-xs"
    >
      {/* Left: Brand & Dropdown Menus */}
      <div className="flex items-center gap-2">
        {/* Brand */}
        <div className="flex items-center gap-1.5 mr-2 font-bold text-slate-100 tracking-tight">
          <span className="text-base">🧠</span>
          <span className="hidden sm:inline font-bold">FreeMind Map Studio</span>
        </div>

        {/* ARCHIVO Menu */}
        <div className="relative">
          <button
            onClick={() => handleMenuClick('file')}
            className={`px-2.5 py-1 rounded-md transition-colors ${
              openMenu === 'file' ? 'bg-slate-800 text-blue-400 font-semibold' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            Archivo
          </button>
          {openMenu === 'file' && (
            <div className="absolute top-full left-0 mt-1 w-56 bg-white text-slate-800 rounded-xl shadow-2xl border border-slate-200 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100">
              <button
                onClick={() => { onNewMap(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600"
              >
                <span className="flex items-center gap-2"><Plus className="w-3.5 h-3.5" /> Nuevo Mapa</span>
              </button>
              <button
                onClick={() => { onOpenTemplates(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600"
              >
                <span className="flex items-center gap-2"><LayoutTemplate className="w-3.5 h-3.5 text-indigo-600" /> Plantillas de Ejemplo</span>
              </button>
              <button
                onClick={() => { onOpenSavedMaps(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600"
              >
                <span className="flex items-center gap-2"><FolderOpen className="w-3.5 h-3.5 text-amber-600" /> Mis Mapas Guardados</span>
              </button>
              <div className="my-1 border-t border-slate-100" />
              <button
                onClick={() => { onSaveMap(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600"
              >
                <span className="flex items-center gap-2"><Save className="w-3.5 h-3.5 text-emerald-600" /> Guardar Ahora</span>
                <kbd className="text-[10px] text-slate-400 font-mono">Ctrl+S</kbd>
              </button>
              <div className="my-1 border-t border-slate-100" />
              <button
                onClick={() => { onOpenExportModal(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between font-semibold text-blue-600 hover:bg-blue-50"
              >
                <span className="flex items-center gap-2"><FileDown className="w-3.5 h-3.5" /> Exportar (.mm / HTML / PNG)</span>
              </button>
              <button
                onClick={() => { onOpenImportModal(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600"
              >
                <span className="flex items-center gap-2"><FileUp className="w-3.5 h-3.5 text-purple-600" /> Importar Freeplane (.mm)</span>
              </button>
            </div>
          )}
        </div>

        {/* EDITAR Menu */}
        <div className="relative">
          <button
            onClick={() => handleMenuClick('edit')}
            className={`px-2.5 py-1 rounded-md transition-colors ${
              openMenu === 'edit' ? 'bg-slate-800 text-blue-400 font-semibold' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            Editar
          </button>
          {openMenu === 'edit' && (
            <div className="absolute top-full left-0 mt-1 w-52 bg-white text-slate-800 rounded-xl shadow-2xl border border-slate-200 py-1.5 z-50">
              <button
                disabled={!canUndo}
                onClick={() => { onUndo(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600 disabled:opacity-40"
              >
                <span className="flex items-center gap-2"><Undo2 className="w-3.5 h-3.5" /> Deshacer</span>
                <kbd className="text-[10px] text-slate-400 font-mono">Ctrl+Z</kbd>
              </button>
              <button
                disabled={!canRedo}
                onClick={() => { onRedo(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600 disabled:opacity-40"
              >
                <span className="flex items-center gap-2"><Redo2 className="w-3.5 h-3.5" /> Rehacer</span>
                <kbd className="text-[10px] text-slate-400 font-mono">Ctrl+Y</kbd>
              </button>
              <div className="my-1 border-t border-slate-100" />
              <button
                onClick={() => { onDeleteNode(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between text-red-600 hover:bg-red-50"
              >
                <span className="flex items-center gap-2"><Trash2 className="w-3.5 h-3.5" /> Eliminar Rama</span>
                <kbd className="text-[10px] text-red-400 font-mono">Supr</kbd>
              </button>
            </div>
          )}
        </div>

        {/* INSERTAR Menu */}
        <div className="relative">
          <button
            onClick={() => handleMenuClick('insert')}
            className={`px-2.5 py-1 rounded-md transition-colors ${
              openMenu === 'insert' ? 'bg-slate-800 text-blue-400 font-semibold' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            Insertar
          </button>
          {openMenu === 'insert' && (
            <div className="absolute top-full left-0 mt-1 w-56 bg-white text-slate-800 rounded-xl shadow-2xl border border-slate-200 py-1.5 z-50">
              <button
                onClick={() => { onAddChild(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600"
              >
                <span className="flex items-center gap-2"><Plus className="w-3.5 h-3.5 text-blue-600" /> Nodo Hijo</span>
                <kbd className="text-[10px] text-slate-400 font-mono">Tab</kbd>
              </button>
              <button
                onClick={() => { onAddSibling(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600"
              >
                <span className="flex items-center gap-2"><Plus className="w-3.5 h-3.5 text-emerald-600" /> Nodo Hermano</span>
                <kbd className="text-[10px] text-slate-400 font-mono">Enter</kbd>
              </button>
              <div className="my-1 border-t border-slate-100" />
              <button
                onClick={() => { onOpenConnectorModal(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center gap-2 hover:bg-blue-50 hover:text-blue-600"
              >
                <Link className="w-3.5 h-3.5 text-cyan-600" /> Conector de Relación
              </button>
              <button
                onClick={() => { onToggleCloud(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center gap-2 hover:bg-blue-50 hover:text-blue-600"
              >
                <Cloud className="w-3.5 h-3.5 text-amber-500" /> Nube de Rama
              </button>
              {onOpenIconPack && (
                <>
                  <div className="my-1 border-t border-slate-100" />
                  <button
                    onClick={() => { onOpenIconPack(); setOpenMenu(null); }}
                    className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600"
                  >
                    <span className="flex items-center gap-2">
                      <Sparkles className="w-3.5 h-3.5 text-indigo-600" /> Pack Iconos Vectoriales
                    </span>
                    <span className="text-[10px] bg-blue-100 text-blue-700 px-1.5 py-0.2 rounded-full font-bold">
                      500+
                    </span>
                  </button>
                </>
              )}
            </div>
          )}
        </div>

        {/* VER Menu */}
        <div className="relative">
          <button
            onClick={() => handleMenuClick('view')}
            className={`px-2.5 py-1 rounded-md transition-colors ${
              openMenu === 'view' ? 'bg-slate-800 text-blue-400 font-semibold' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            Ver
          </button>
          {openMenu === 'view' && (
            <div className="absolute top-full left-0 mt-1 w-56 bg-white text-slate-800 rounded-xl shadow-2xl border border-slate-200 py-1.5 z-50">
              <button
                onClick={() => { onToggleOutline(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600"
              >
                <span className="flex items-center gap-2"><ListTree className="w-3.5 h-3.5 text-indigo-600" /> Panel Lateral de Esquema</span>
                <kbd className="text-[10px] text-slate-400 font-mono">Alt+O</kbd>
              </button>
              <button
                onClick={() => { onStartPresentation(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600"
              >
                <span className="flex items-center gap-2"><Presentation className="w-3.5 h-3.5 text-purple-600" /> Modo Presentación</span>
                <kbd className="text-[10px] text-slate-400 font-mono">F5</kbd>
              </button>
              <div className="my-1 border-t border-slate-100" />
              <button
                onClick={() => { onUnfoldAll(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center gap-2 hover:bg-blue-50 hover:text-blue-600"
              >
                <span>Desplegar Todo el Mapa</span>
              </button>
              <button
                onClick={() => { onFoldAll(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center gap-2 hover:bg-blue-50 hover:text-blue-600"
              >
                <span>Plegar Todas las Ramas</span>
              </button>
              <div className="my-1 border-t border-slate-100" />
              <button
                onClick={() => { onToggleFullscreen(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600"
              >
                <span className="flex items-center gap-2"><Maximize className="w-3.5 h-3.5" /> Pantalla Completa</span>
                <kbd className="text-[10px] text-slate-400 font-mono">F11</kbd>
              </button>
            </div>
          )}
        </div>

        {/* AYUDA Menu */}
        <div className="relative">
          <button
            onClick={() => handleMenuClick('help')}
            className={`px-2.5 py-1 rounded-md transition-colors ${
              openMenu === 'help' ? 'bg-slate-800 text-blue-400 font-semibold' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            Ayuda
          </button>
          {openMenu === 'help' && (
            <div className="absolute top-full left-0 mt-1 w-56 bg-white text-slate-800 rounded-xl shadow-2xl border border-slate-200 py-1.5 z-50">
              <button
                onClick={() => { onOpenShortcuts(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center justify-between hover:bg-blue-50 hover:text-blue-600 font-medium"
              >
                <span className="flex items-center gap-2"><HelpCircle className="w-3.5 h-3.5 text-blue-600" /> Atajos de Teclado</span>
                <kbd className="text-[10px] text-slate-400 font-mono">?</kbd>
              </button>
              <button
                onClick={() => { onOpenTemplates(); setOpenMenu(null); }}
                className="w-full px-3 py-1.5 text-left flex items-center gap-2 hover:bg-blue-50 hover:text-blue-600"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-500" /> Guía Tutorial Freeplane
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Center: Editable Map Title */}
      <div className="flex-1 max-w-sm mx-4 text-center">
        {isEditingTitle ? (
          <input
            type="text"
            autoFocus
            value={titleInput}
            onChange={(e) => setTitleInput(e.target.value)}
            onBlur={handleTitleSubmit}
            onKeyDown={(e) => e.key === 'Enter' && handleTitleSubmit()}
            className="w-full bg-slate-800 border border-blue-500 rounded px-2 py-0.5 text-xs text-white font-medium text-center outline-none"
          />
        ) : (
          <div
            title="Doble clic para cambiar el título del mapa"
            onDoubleClick={() => setIsEditingTitle(true)}
            className="cursor-pointer hover:bg-slate-800/80 px-2 py-0.5 rounded text-xs font-semibold text-slate-200 truncate transition-colors"
          >
            {mindMap.title}
          </div>
        )}
      </div>

      {/* Right: Offline Indicator */}
      <div className="flex items-center gap-2 shrink-0">
        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-800/60 text-emerald-400 text-[11px] font-medium">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="hidden md:inline">100% Offline</span>
        </div>
      </div>
    </header>
  );
};
